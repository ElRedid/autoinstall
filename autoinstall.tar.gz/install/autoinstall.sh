#!/bin/bash
# autoinstall.sh - Version mejorada del install.sh
# Autor: Julio Colman <julio.colmant@gmail.com>
# Script basado en el install.sh desarrollado por Ali do Amaral Pedrozo
NOMBRE=""
PUERTO_SELECCIONADO=22
# Mensaje de recomendaciones, aparece al cuminar el proceso de preparacion del servidor
recomendacao() {
    clear
	echo " ================================================= "
	echo " Recomendaciones:                                  "
	echo "   -> Verificar si el cliente tiene BACKUP         "
	echo "      LOCAL/ONLINE                                "
	echo "   -> N.U.N.C.A olvide instalar el BACKUP          "
	echo "   -> Herramientas adicionales disponibles en      "
	echo "       tools y scripts                             "
    echo "                                                   "
    echo "          --> REINICIE EL SERVIDOR <--             "
	echo " ================================================= "
	sleep 5
}
# Gestor ADS
preguntainstalarads(){
    dialog --clear --title "ADS" --yesno "\nDesea instalar ADS?" 8 70
    respuesta=$?
    case $respuesta in
        0)
            instalarads
            ;;
        1)
            clear
            ;;
        255)
            clear
            ;;
    esac
}
# Proceso de instalacion ADS
instalarads(){
    clear
    $PARAMETRO -y install perl-File-Copy glibc.i686 libstdc++.i686 libslang.so.2
    baseads
	/opt/install/tools/serialcode.sh
	/opt/install/tools/adslinux.intrn-7.10.0/addserialads.sh
	/opt/install/tools/adslinux.intrn-7.10.0/setup.pl
	cp -f /opt/install/tools/ads.service /etc/systemd/system/
    systemctl daemon-reload > /dev/null 2>&1
	systemctl enable ads > /dev/null 2>&1
	systemctl restart ads > /dev/null 2>&1
    rm -Rf /var/log/advantage/*
}
# Herramienta xdbu
xdbuads () {
    clear
    sleep 2
    cp /opt/install/tools/xdbuads /usr/sbin/ > /dev/null 2>&1
    echo "----> xdbuads agregado a /usr/sbin/"
    sleep 5
}
# Menu de instalacion ADS
menuads() {
    local opciones=(
        1 "Instalar ADS"
        2 "Instalar xdbuads"
        3 "Volver"
    )
    seleccion=$(dialog --clear \
                    --title "INFOSERVE - MARIADB" \
                    --menu "Seleccione una de las siguientes opciones:" 15 50 4 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)
    case $seleccion in
        1) 
            preguntainstalarads 
            menuads ;;
        2) 
            xdbuads 
            menuads ;;
        3) 
            menu ;;
        *) 
            clear ;;
    esac
}
# Crea db y user mariadb
mariadbuser () {
    DATABASE=$(dialog --clear \
                    --title "MARIADB" \
                    --inputbox "Nombre para la base de datos: \nSe creara un administrador de base de datos con el mismo nombre de la base de datos" 10 70 \
                    2>&1 >/dev/tty)
    if [ -n "$DATABASE" ]; then
        dialog --clear --title "MARIADB" --yesno "\nDesea confirmar el siguiente nombre para la base de datos?\n ---> $DATABASE" 8 70
        respuesta=$?
        case $respuesta in
        0)
            mariadb -uroot -p@info2016! -e "create database $DATABASE; grant all on $DATABASE.* to $DATABASE@'%' identified by '@info2016\!'; grant all on $DATABASE.* to $DATABASE@'localhost' identified by '@info2016\!';FLUSH PRIVILEGES;"
            ;;
        1)
            mariadbuser
            ;;
        255)
            clear
            ;;
        esac
    else
        clear
    fi
}
menumariadb() {
    local opciones=(
        1 "Instalar Mariadb"
        2 "Desinstalar Mariadb"
        3 "Agregar Database y User"
        4 "Volver"
    )
    seleccion=$(dialog --clear \
                    --title "INFOSERVE - MARIADB" \
                    --menu "Seleccione una de las siguientes opciones:" 15 50 4 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)
    case $seleccion in
        1) 
            preguntainstalarmysql 
            menumariadb ;;
        2)
            preguntadesinstalarmysql
            menumariadb ;;
        3) 
            mariadbuser 
            menumariadb ;;
        4) 
            menu ;;
        *) 
            clear ;;
    esac
}
# Gestiona instalacion mariadb --MODIFICAR
instalarmysql(){
    clear
	cp /opt/install/tools/my.cnf /etc/
	wget https://downloads.mariadb.com/MariaDB/mariadb_repo_setup -O /opt/install/tools/mariadb_repo_setup
	chmod +x /opt/install/tools/mariadb_repo_setup
	/opt/install/tools/mariadb_repo_setup --mariadb-server-version="mariadb-11.8"
	$PARAMETRO -y install MariaDB-server MariaDB-client
	systemctl start mariadb
	systemctl enable mariadb
	mariadb-admin -uroot password '@info2016!'
    mariadb -uroot -p@info2016! -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '@info2016!';FLUSH PRIVILEGES;"
    mariadbuser
}
# Elimina base de datos mariadb
desinstalarmysql(){
    clear
    systemctl stop mariadb > /dev/null 2>&1
    systemctl disable mariadb > /dev/null 2>&1
    $PARAMETRO -y remove mariadb mariadb-server
    rm -rf /var/lib/mysql > /dev/null 2>&1
    rm -rf /etc/my.cnf > /dev/null 2>&1
    $PARAMETRO -y autoremove
    userdel mysql > /dev/null 2>&1
    groupdel mysql > /dev/null 2>&1
    $PARAMETRO clean all
    rm -rf /var/log/mysql > /dev/null 2>&1
}
# Pregunta instalar mariadb
preguntainstalarmysql(){
    dialog --clear --title "MARIADB" --yesno "\nDesea instalar MARIADB?" 8 70
        respuesta=$?
        case $respuesta in
        0)
            instalarmysql
            ;;
        1)
            clear
            ;;
        255)
            clear
            ;;
        esac
}
# Pregunta desinstalar mariadb
preguntadesinstalarmysql(){
    dialog --clear --title "DESINSTALAR MARIADB" --yesno "\nDesea desinstalar MARIADB?" 8 70
        respuesta=$?
        case $respuesta in
        0)
            desinstalarmysql
            ;;
        1)
            clear
            ;;
        255)
            clear
            ;;
        esac
}
# Agrega driver generico para pos80 3nStart
cupsdrivers(){
	tar zxvf /opt/install/tools/p3nstart.tar.gz -C /opt/install/tools/ > /dev/null 2>&1
    /opt/install/tools/p3nstart/install.sh > /dev/null 2>&1
    systemctl restart cups > /dev/null 2>&1
}
# Configuracion CUPS
cupsconf(){
	cp -f /opt/install/tools/cupsd.conf /etc/cups/cupsd.conf
	systemctl restart cups > /dev/null 2>&1
}
# Script que suplanta el comando passwd
passwdmod(){
	cp /opt/install/scripts/passwd.sh /bin/
	if ! grep -Fxq "alias passwd='passwd.sh'" /root/.bashrc; then
        echo "alias passwd='passwd.sh'" >> /root/.bashrc
    fi
}
# Configuracion ssh
sshc(){
    sed -i 's/^#PermitRootLogin.*$/#PermitRootLogin yes/' /etc/ssh/sshd_config
    sed -i 's/^PermitRootLogin.*$/PermitRootLogin no/' /etc/ssh/sshd_config
    if ! grep -q "^PermitRootLogin no" /etc/ssh/sshd_config; then
        echo "PermitRootLogin no" >> /etc/ssh/sshd_config
    fi
    systemctl restart sshd	
}
# Menu seleccionar puerto
seleccionar_puerto() {
     local opciones=(
        1 "Puerto 45000"
        2 "Puerto 22 (por defecto)"
    )
    seleccione=$(dialog --clear \
                    --title "Selecciona Puerto SSH" \
                    --menu "Seleccione el puerto de SSH:" 15 50 2 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)
    case $seleccione in
        1)
            PUERTO_SELECCIONADO=45000
            confirmar_puerto
            ;;
        2)
            PUERTO_SELECCIONADO=22
            confirmar_puerto
            ;;
        *)
            puerto_default
            ;;
    esac
}
# Pregunta definir puerto
confirmar_puerto() {
    dialog --clear --title "Confirmacion de Puerto SSH" --yesno "Esta seguro de usar el puerto $PUERTO_SELECCIONADO?" 7 70
    respuesta=$?
    case $respuesta in
    0)
        configurar_ssh
        ;;
    1)
        seleccionar_puerto
        ;;
    255)
        seleccionar_puerto
        ;;
    esac
}
# Pregunta confirmar puerto seleccionado 
puerto_default() {
    dialog --clear --title "Confirmacion de Puerto SSH" --yesno "Esta seguro de usar el puerto $PUERTO_SELECCIONADO?" 7 70
    respuesta=$?
    case $respuesta in
    0)
        configurar_ssh
        ;;
    1)
        seleccionar_puerto
        ;;
    255)
        seleccionar_puerto
        ;;
    esac
}
# Configura puerto para el servidor
configurar_ssh() {
    clear
    if grep -q "^#Port " /etc/ssh/sshd_config; then
        sed -i "s/^#Port .*/Port $PUERTO_SELECCIONADO/" /etc/ssh/sshd_config
    elif grep -q "^Port " /etc/ssh/sshd_config; then
        sed -i "s/^Port .*/Port $PUERTO_SELECCIONADO/" /etc/ssh/sshd_config
    else
        echo "Port $PUERTO_SELECCIONADO" >> /etc/ssh/sshd_config
    fi
    systemctl restart sshd > /dev/null 2>&1
}
# Deshabilita selinux
dselinux(){
	sed -e "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config > /etc/selinux/config.tmp
	mv /etc/selinux/config /etc/selinux/config.seg
	mv /etc/selinux/config.tmp /etc/selinux/config
}
# Copia librerias necesarias
librerias(){
	cp -f ./lib/* /lib/
    cp -f ./librocky/* /usr/lib64/
	ldconfig
}
# Configuracion FTP
ftp(){
	mv /etc/vsftpd/vsftpd.conf /root/vsftpd.conf.org > /dev/null 2>&1
	cp /opt/install/tools/vsftpd.conf /etc/vsftpd/ > /dev/null 2>&1
	systemctl restart vsftpd.service > /dev/null 2>&1
	systemctl enable vsftpd.service	> /dev/null 2>&1
	systemctl disable firewalld > /dev/null 2>&1
	systemctl stop firewalld > /dev/null 2>&1
}
# Directorios basicos
directoriosadicionales () {
    mkdir /etc/harbour > /dev/null 2>&1
	mkdir /sistema > /dev/null 2>&1
	mkdir /etc/init.d > /dev/null 2>&1
    mkdir /usr/etc > /dev/null 2>&1
    mkdir /opt/scripts > /dev/null 2>&1
}
# Direccion Absoluta 1.0.3
baseads () {
	tar zxvf /opt/install/tools/adslinux-7.10.0.tar.gz -C /opt/install/tools/ > /dev/null 2>&1
	tar zxvf /opt/install/tools/arc-7.10.0.tar.gz -C /opt/install/tools/ > /dev/null 2>&1
    cp -f /opt/install/tools/adslinux.intrn-7.10.0/setpermissions.pl /usr/sbin/ > /dev/null 2>&1
    cp -f /opt/install/tools/xdbuads /usr/sbin/ > /dev/null 2>&1
}
# Entorno y utilidades
entorno () {
    sed '1a\
	export HB_TERM=linux/acsc' /etc/profile > /tmp/profile.tmp
	cp /tmp/profile.tmp /etc/profile
	rm -f /tmp/profile.tmp
    directoriosadicionales
    cp /opt/install/complementos/hb-charmap.def /etc/harbour  
    cp /opt/install/tools/rpr /usr/bin
	chmod 777 /usr/bin/rpr
    baseads 
    localectl set-keymap us-acentos
    echo >> /etc/sudoers
    grep -qxF "## Configurar los usuarios o grupos para ejecutar comando de sudo sin pedir passwd" /etc/sudoers || echo "## Configurar los usuarios o grupos para ejecutar comando de sudo sin pedir passwd" >> /etc/sudoers
    grep -qxF "  autoapagado   ALL=(ALL)       NOPASSWD: /sbin/shutdown -h now" /etc/sudoers || echo "  autoapagado   ALL=(ALL)       NOPASSWD: /sbin/shutdown -h now" >> /etc/sudoers
    grep -qxF "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/systemctl restart cups" /etc/sudoers || echo "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/systemctl restart cups" >> /etc/sudoers
    grep -qxF "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/rm /var/spool/cups/* -Rf" /etc/sudoers || echo "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/rm /var/spool/cups/* -Rf" >> /etc/sudoers
    cp -f /opt/install/complementos/adsd_check.sh /opt/install/complementos/printer_check.sh /opt/install/complementos/menu_impresoras.sh /opt/scripts
}
# Paquetes necesarios en el sistema
paquetes () {
    clear
    $PARAMETRO -y upgrade
    pack=("net-tools" 
          "vsftpd" 
          "cups" 
          "psmisc" 
          "samba-client.x86_64" 
          "enscript" 
          "ghostscript" 
          "glibc.i686" 
          "libstdc++.i686" 
          "gpm" 
          "unzip" 
          "zip"
          "rsync" 
          "tigervnc-server" 
          "perl-File-Copy" 
          "libslang.so.2" 
          "epel-release" 
          "ncdu" 
          "fd-find" 
          "tldr" 
          "wget" 
          "bzip2" 
          "cmake" 
          "gcc" 
          "gcc-c++" 
          "vim" 
          "hplip"
          "tree"
          "htop"
          "cups-devel")
    total_paquetes=${#pack[@]}
    (
    for i in "${!pack[@]}"; do
        progreso=$(( (i + 1) * 100 / total_paquetes ))
        echo $progreso
        $PARAMETRO -y install "${pack[$i]}" > /dev/null 2>&1
    done
    ) | dialog --title "Preparando entorno" --gauge "Instalando paquetes..." 8 70 0
}
# Funcion principal que ejecuta la secuenca de preparacion del servidor
order () {
    paquetes
    entorno
    ftp
    librerias
    dselinux
    sshc
    seleccionar_puerto
    passwdmod
    cupsconf
    cupsdrivers
    preguntainstalarmysql
    preguntainstalarads
    recomendacao
    exec $SHELL
}
# Usuarios personalizados - Utilidades sistema
users-groups () {
    groupadd apache > /dev/null 2>&1
    adduser cups > /dev/null 2>&1
    echo "cups!." | passwd --stdin cups > /dev/null 2>&1
    if ! grep -q "cd /opt/scripts/" /home/cups/.bash_profile; then
        echo "cd /opt/scripts/" >> /home/cups/.bash_profile
    fi
    if ! grep -q "/opt/complementos/menu_impresoras.sh" /home/cups/.bash_profile; then
        echo "/opt/complementos/menu_impresoras.sh" >> /home/cups/.bash_profile
    fi
    if ! grep -q "logout" /home/cups/.bash_profile; then
        echo "logout" >> /home/cups/.bash_profile
    fi
    adduser autoapagado > /dev/null 2>&1
    echo "autoapagado!." | passwd --stdin autoapagado > /dev/null 2>&1
    if ! grep -q "sudo /sbin/shutdown -h now" /home/autoapagado/.bash_profile; then
        echo "sudo /sbin/shutdown -h now" >> /home/autoapagado/.bash_profile
    fi
    if ! grep -q "logout" /home/autoapagado/.bash_profile; then
        echo "logout" >> /home/autoapagado/.bash_profile
    fi
}
# Funcion nombre para el servidor
server-name () {
    NOMBRE="svr-$1"
    hostnamectl set-hostname "$NOMBRE"
    echo "127.0.0.1   $NOMBRE $NOMBRE.localdomain $NOMBRE $NOMBRE.localdomain4" > /etc/hosts
    echo "::1         $NOMBRE $NOMBRE.localdomain $NOMBRE $NOMBRE.localdomain6" >> /etc/hosts
}
# Define nombre al servidor y agrega grupos
name () {
    NOMBRE=$(dialog --clear \
                    --title "Nombre para el servidor" \
                    --inputbox "Por favor, ingrese nombre para el servidor: \nSe le agregara el prefijo svr- al nombre proporcionado ej: \nteste -> svr-teste" 10 70 \
                    2>&1 >/dev/tty)
    if [ -n "$NOMBRE" ]; then
        dialog --clear --title "Nombre para el servidor" --yesno "\nDesea confirmar el siguiente nombre para el servidor?\nsvr-$NOMBRE" 8 70
        respuesta=$?
        case $respuesta in
        0)
            clear
            server-name "$NOMBRE"
            users-groups 
            order
            ;;
        1)
            name
            ;;
        255)
            clear
            ;;
        esac

    else
        menu
    fi
}
# Menu del Instalador
menu() {
    local opciones=(
        1 "Instalacion completa."
        2 "Gestor MariaDB."
        3 "Gestor Ads."
        4 "Salir."
    )
    seleccion=$(dialog --clear \
                    --title "INFOSERVE - AUTOINSTALL $DISTRO" \
                    --menu "Seleccione una de las siguientes opciones:" 15 50 4 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)
    case $seleccion in
        1) 
            name ;;
        2) 
            menumariadb ;;
        3) 
            menuads ;;
        4) 
            clear ;;
        *) 
            clear ;;
    esac
}
# Consulta Proceder con la instalacion
ejecutar () {
    dialog --clear --title "AUTO-INSTALL INFOSERVE - $DISTRO" --yesno "Desea realizar la instalacion?" 6 50
    respuesta=$?
    case $respuesta in
    0)
        menu
        ;;
    1)
        clear
        ;;
    255)
        clear
        ;;
    esac
}
# Verifica dialog  para instalar o en todo caso abortar instalacion
consultandodialog() {
    if command -v dialog > /dev/null 2>&1; then
        ejecutar
    else
        echo -e "\033[36mInstalando dialog...\033[0m"
        $PARAMETRO -y install dialog > /dev/null 2>&1
        if command -v dialog > /dev/null 2>&1; then
            ejecutar
        else
            echo "Error al intentar instalar 'dialog'. Por favor, verifica tu conexion o el repositorio."
            exit 1 
        fi
    fi
}
# Mensaje sin internet
mensajenointernet () {
    echo -e " ================================================= "
    echo -e "                                                   "
    echo -e "            SIN CONEXION A INTERNET                "
    echo -e "                                                   "
    echo -e "    No se pudo establecer conexion a internet.     "
    echo -e "    * Verifique que el cable de red este conectado "
    echo -e "    * Intente utilizar un DNS publico ej: 8.8.8.8  "
    echo -e "    * Si ha modificado la configuracion de la placa"
    echo -e "      de red, reinicie el equipo para aplicar los  "
    echo -e "      cambios y vuelva a intentarlo.               "
    echo -e "                                                   "
    echo -e " ================================================= "
}
# Funcion verifica internet
checkinternet () {
    if ping -c 1 google.com > /dev/null 2>&1; then
        consultandodialog
    else
        mensajenointernet
        exit 1
    fi
}
# Mensaje caso distro no valida
mensajedistronocompatible () {
    echo -e " ================================================= "
    echo -e "                                                   "
    echo -e "       SISTEMA OPERATIVO NO COMPATIBLE             "
    echo -e "                                                   "
    echo -e "    La distribucion Linux que estatilizando        "
    echo -e "    no es compatible con este autoinstalador.      "
    echo -e "                                                   "
    echo -e "    Si su sistema es CentOS, se le recomienda      "
    echo -e "        actualizar a Rocky o Alma Linux.           "
    echo -e "                                                   "
    echo -e " ================================================= "
}
# Funcion que comprueba si es una distro valida
distro () { 
    local file="/etc/redhat-release"
    if [[ ! -f $file ]]; then
        DISTRO="Desconocida"
        return
    fi
    if grep -qi "Rocky" "$file"; then
        DISTRO="Rocky Linux"
        PARAMETRO='dnf'
    elif grep -qi "Alma" "$file"; then
        DISTRO="Alma Linux"
        PARAMETRO='dnf'
    #elif grep -qi "Cent" "$file"; then
    #    DISTRO="Centos Linux"
    #    PARAMETRO='yum'
    else
        DISTRO="Desconocida"
    fi
}
# Verifica distro y si hay internet
init () {
    distro
    if [ "$DISTRO" = "Desconocida" ]; then
        mensajedistronocompatible
        exit 1
    else       
        checkinternet
    fi
}
# Verifica si el usuario es ROOT
if [ "$(id -u)" -ne 0 ]; then
    echo -e " ====================================================================== "
    echo -e "                                                                        "
    echo -e "          -> Para poder ejecutar el instalador debe de                  "
    echo -e "                 estar logueado como usuario ROOT.                      "
    echo -e "                                                                        "
    echo -e "                      CERRANDO INSTALADOR...                            "
    echo -e "                                                                        "
    echo -e " ====================================================================== "
    exit 1 
else
    init
fi
