#!/bin/bash
# autoinstall.sh - Version mejorada del install.sh
# Autor: Julio Colman <julio.colmant@gmail.com>
# Script basado en el install.sh desarrollado por Ali do Amaral Pedrozo


TOOLS="./tools/"
NOMBRE=""
VERSION=170125
PUERTO_SELECCIONADO=22

recomendacao() {

    clear
	echo " ================================================= "
	echo " Recomendaciones:                                  "
	echo "   -> Verificar si el cliente tiene BACKUP         "
	echo "      LOCAL/ONLINE                                "
	echo "   -> N.U.N.C.A olvide instalar el BACKUP          "
	echo "   -> Herramientas adicionales disponibles en      "
	echo "       tools y scripts                             "
    echo "                                                   "
    echo "          --> REINICIE EL SERVIDOR <--             "
	echo " ================================================= "
	sleep 5

}

preguntainstalarads(){

    dialog --clear --title "ADS" --yesno "\nDesea instalar ADS?" 8 70

        respuesta=$?

        case $respuesta in
        0)
            instalarads
            ;;
        1)
            clear
            ;;
        255)
            clear
            ;;
        esac

}

instalarads(){

    clear
    $PARAMETRO -y install perl-File-Copy glibc.i686 libstdc++.i686 libslang.so.2
    librerias
    baseads
    directoriosadicionales


    cd $TOOLS
	./serialcode.sh
	cd ./adslinux.intrn-7.10.0
	./addserialads.sh
	./setup.pl
    cd ..
	cp -f ads.service /etc/systemd/system/
    systemctl daemon-reload > /dev/null 2>&1
	systemctl enable ads > /dev/null 2>&1
	systemctl restart ads > /dev/null 2>&1
    rm -Rf /var/log/advantage/*
    cd ..

}

xdbuads () {
    clear
    sleep 2
    cd $TOOLS > /dev/null 2>&1
    cp xdbuads /usr/sbin/ > /dev/null 2>&1
    cd ..
    echo "----> xdbuads agregado a /usr/sbin/"
    sleep 5
}

menuads() {

    local opciones=(
        1 "Instalar ADS"
        2 "Instalar xdbuads"
        3 "Volver"
    )

    # Muestra el menu y capturar la seleccion del usuario.
    seleccion=$(dialog --clear \
                    --title "INFOSERVE - MARIADB" \
                    --menu "Seleccione una de las siguientes opciones:" 15 50 4 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)

    # Interpretar la seleccióel usuario
    case $seleccion in
        1) 
            preguntainstalarads 
            menuads ;;
        2) 
            xdbuads 
            menuads ;;
        3) 
            menu ;;
        *) 
            clear ;;
    esac
}

mariadbuser () {

    DATABASE=$(dialog --clear \
                    --title "MARIADB" \
                    --inputbox "Nombre para la base de datos: \nSe creara un administrador de base de datos con el mismo nombre de la base de datos" 10 70 \
                    2>&1 >/dev/tty)

    if [ -n "$DATABASE" ]; then

        dialog --clear --title "MARIADB" --yesno "\nDesea confirmar el siguiente nombre para la base de datos?\n ---> $DATABASE" 8 70

        respuesta=$?

        case $respuesta in
        0)
            mariadb -uroot -p@info2016! -e "create database $DATABASE; grant all on $DATABASE.* to $DATABASE@'%' identified by '@info2016\!'; grant all on $DATABASE.* to $DATABASE@'localhost' identified by '@info2016\!';FLUSH PRIVILEGES;"
            ;;
        1)
            mariadbuser
            ;;
        255)
            clear
            ;;
        esac

    else
        clear
    fi

}

menumariadb() {

    local opciones=(
        1 "Instalar Mariadb"
        2 "Desinstalar Mariadb"
        3 "Agregar Database y User"
        4 "Volver"
    )

    # Muestra el menu y capturar la seleccion del usuario.
    seleccion=$(dialog --clear \
                    --title "INFOSERVE - MARIADB" \
                    --menu "Seleccione una de las siguientes opciones:" 15 50 4 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)

    # Interpretar la seleccióel usuario
    case $seleccion in
        1) 
            preguntainstalarmysql 
            menumariadb ;;
        2)
            preguntadesinstalarmysql
            menumariadb ;;
        3) 
            mariadbuser 
            menumariadb ;;
        4) 
            menu ;;
        *) 
            clear ;;
    esac
}

instalarmysql(){

    clear
    $PARAMETRO -y install wget 
	cd $TOOLS
	cp my.cnf /etc/
	wget https://downloads.mariadb.com/MariaDB/mariadb_repo_setup
	chmod +x mariadb_repo_setup
	./mariadb_repo_setup --mariadb-server-version="mariadb-11.8"
	$PARAMETRO -y install MariaDB-server MariaDB-client
	systemctl start mariadb
	systemctl enable mariadb
	mariadb-admin -uroot password '@info2016!'
    mariadb -uroot -p@info2016! -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '@info2016!';FLUSH PRIVILEGES;"
    cd ..
    mariadbuser

}

desinstalarmysql(){

    clear
    systemctl stop mariadb > /dev/null 2>&1
    systemctl disable mariadb > /dev/null 2>&1
    $PARAMETRO -y remove mariadb mariadb-server
    rm -rf /var/lib/mysql > /dev/null 2>&1
    rm -rf /etc/my.cnf > /dev/null 2>&1
    $PARAMETRO -y autoremove
    userdel mysql > /dev/null 2>&1
    groupdel mysql > /dev/null 2>&1
    $PARAMETRO clean all
    rm -rf /var/log/mysql > /dev/null 2>&1

}

preguntainstalarmysql(){

    dialog --clear --title "MARIADB" --yesno "\nDesea instalar MARIADB?" 8 70

        respuesta=$?

        case $respuesta in
        0)
            instalarmysql
            ;;
        1)
            clear
            ;;
        255)
            clear
            ;;
        esac

}

preguntadesinstalarmysql(){

    dialog --clear --title "DESINSTALAR MARIADB" --yesno "\nDesea desinstalar MARIADB?" 8 70

        respuesta=$?

        case $respuesta in
        0)
            desinstalarmysql
            ;;
        1)
            clear
            ;;
        255)
            clear
            ;;
        esac

}

cupsdrivers(){

	cd $TOOLS 
	tar zxvf p3nstart.tar.gz > /dev/null 2>&1
    cd p3nstart
    ./install.sh > /dev/null 2>&1
    systemctl restart cups > /dev/null 2>&1
	cd ..
    cd ..

}

cupsconf(){

	cd $TOOLS 
	cp -f cupsd.conf /etc/cups/cupsd.conf
	systemctl restart cups > /dev/null 2>&1
	cd ..

}

passwdmod(){

	cd ./scripts
	cp passwd.sh /bin/
	if ! grep -Fxq "alias passwd='passwd.sh'" /root/.bashrc; then
        echo "alias passwd='passwd.sh'" >> /root/.bashrc
    fi
	cd ..

}

sshc(){

    sed -i 's/^#PermitRootLogin.*$/#PermitRootLogin yes/' /etc/ssh/sshd_config
    sed -i 's/^PermitRootLogin.*$/PermitRootLogin no/' /etc/ssh/sshd_config

    if ! grep -q "^PermitRootLogin no" /etc/ssh/sshd_config; then
        echo "PermitRootLogin no" >> /etc/ssh/sshd_config
    fi

    systemctl restart sshd
	
}

seleccionar_puerto() {

     local opciones=(
        1 "Puerto 45000"
        2 "Puerto 22 (por defecto)"
    )
    
    seleccione=$(dialog --clear \
                    --title "Selecciona Puerto SSH" \
                    --menu "Seleccione el puerto de SSH:" 15 50 2 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)

    # Interpretar la seleccióel usuario
    case $seleccione in
        1)
            PUERTO_SELECCIONADO=45000
            confirmar_puerto
            ;;
        2)
            PUERTO_SELECCIONADO=22
            confirmar_puerto
            ;;
        *)
            puerto_default
            ;;
    esac
}

confirmar_puerto() {

    dialog --clear --title "Confirmacion de Puerto SSH" --yesno "Esta seguro de usar el puerto $PUERTO_SELECCIONADO?" 7 70

    respuesta=$?

    case $respuesta in
    0)
        configurar_ssh
        ;;
    1)
        seleccionar_puerto
        ;;
    255)
        seleccionar_puerto
        ;;
    esac
}

puerto_default() {
    
    dialog --clear --title "Confirmacion de Puerto SSH" --yesno "Esta seguro de usar el puerto $PUERTO_SELECCIONADO?" 7 70

    respuesta=$?

    case $respuesta in
    0)
        configurar_ssh
        ;;
    1)
        seleccionar_puerto
        ;;
    255)
        seleccionar_puerto
        ;;
    esac
}


configurar_ssh() {

    clear

    if grep -q "^#Port " /etc/ssh/sshd_config; then
        sed -i "s/^#Port .*/Port $PUERTO_SELECCIONADO/" /etc/ssh/sshd_config
    elif grep -q "^Port " /etc/ssh/sshd_config; then
        sed -i "s/^Port .*/Port $PUERTO_SELECCIONADO/" /etc/ssh/sshd_config
    else
        echo "Port $PUERTO_SELECCIONADO" >> /etc/ssh/sshd_config
    fi


    systemctl restart sshd > /dev/null 2>&1

}

#listo
dselinux(){

	sed -e "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config > /etc/selinux/config.tmp
	mv /etc/selinux/config /etc/selinux/config.seg
	mv /etc/selinux/config.tmp /etc/selinux/config

}
#listo
librerias(){

	cp -f ./lib/* /lib/
    cp -f ./librocky/* /usr/lib64/
	ldconfig

}
#listo
ftp(){

	#Moviendo archivo de configuracion base a carpeta infoserve
	mv /etc/vsftpd/vsftpd.conf /root/vsftpd.conf.org > /dev/null 2>&1
	#Copiando archivo preconfigurado a la carpeta de vsfpd
    cd $TOOLS
	cp vsftpd.conf /etc/vsftpd/ > /dev/null 2>&1
	#Aplicando cambios al entorno
	systemctl restart vsftpd.service > /dev/null 2>&1
	systemctl enable vsftpd.service	> /dev/null 2>&1
	systemctl disable firewalld > /dev/null 2>&1
	systemctl stop firewalld > /dev/null 2>&1
    cd ..

}

directoriosadicionales () {
    mkdir /etc/harbour > /dev/null 2>&1
	mkdir /sistema > /dev/null 2>&1
	mkdir /etc/init.d > /dev/null 2>&1
    mkdir /usr/etc > /dev/null 2>&1
    mkdir /opt/scripts > /dev/null 2>&1
}

baseads () {
    
    cd $TOOLS
	tar zxvf adslinux-7.10.0.tar.gz > /dev/null 2>&1
	tar zxvf arc-7.10.0.tar.gz > /dev/null 2>&1
    cp -f adslinux.intrn-7.10.0/setpermissions.pl /usr/sbin/ > /dev/null 2>&1
    cp -f xdbuads /usr/sbin/ > /dev/null 2>&1
    cd ..
}
#listo
entorno () {

    sed '1a\
	export HB_TERM=linux/acsc' /etc/profile > /tmp/profile.tmp
	cp /tmp/profile.tmp /etc/profile
	rm -f /tmp/profile.tmp

    directoriosadicionales

    cp complementos/hb-charmap.def /etc/harbour  
    cp $TOOLS/rpr /usr/bin
	chmod 777 /usr/bin/rpr

    baseads 

    localectl set-keymap us-acentos

    echo >> /etc/sudoers

    # Agregar la linea para configurar los usuarios solo si no existe
    grep -qxF "## Configurar los usuarios o grupos para ejecutar comando de sudo sin pedir passwd" /etc/sudoers || echo "## Configurar los usuarios o grupos para ejecutar comando de sudo sin pedir passwd" >> /etc/sudoers

    # Agregar las lineas para autoapagado y cups solo si no existen
    grep -qxF "  autoapagado   ALL=(ALL)       NOPASSWD: /sbin/shutdown -h now" /etc/sudoers || echo "  autoapagado   ALL=(ALL)       NOPASSWD: /sbin/shutdown -h now" >> /etc/sudoers
    grep -qxF "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/systemctl restart cups" /etc/sudoers || echo "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/systemctl restart cups" >> /etc/sudoers
    grep -qxF "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/rm /var/spool/cups/* -Rf" /etc/sudoers || echo "  cups          ALL=(ALL)       NOPASSWD: /usr/bin/rm /var/spool/cups/* -Rf" >> /etc/sudoers


    cd ./complementos
    cp -f adsd_check.sh printer_check.sh menu_impresoras.sh /opt/scripts
    cd ..

   
}
#listo
paquetes () {
    # Instala todos los paquetes necesarios para el sistema
    clear
    $PARAMETRO -y upgrade
    # Lista de paquetes a instalar
    pack=("net-tools" 
          "vsftpd" 
          "cups" 
          "psmisc" 
          "samba-client.x86_64" 
          "enscript" 
          "ghostscript" 
          "glibc.i686" 
          "libstdc++.i686" 
          "gpm" 
          "unzip" 
          "rsync" 
          "tigervnc-server" 
          "perl-File-Copy" 
          "libslang.so.2" 
          "epel-release" 
          "ncdu" 
          "fd-find" 
          "tldr" 
          "wget" 
          "bzip2" 
          "cmake" 
          "gcc" 
          "gcc-c++" 
          "cups-devel")

    # Total de paquetes a instalar
    total_paquetes=${#pack[@]}

    # Inicia el dialog con una barra de progreso
    (
    # Itera a traves de los paquetes y actualiza la barra de progreso
    for i in "${!pack[@]}"; do
        # Calcula el progreso (porcentaje)
        progreso=$(( (i + 1) * 100 / total_paquetes ))

        # Muestra el progreso y el nombre del paquete en el mismo flujo
        echo $progreso

        # Instala el paquete
        $PARAMETRO -y install "${pack[$i]}" > /dev/null 2>&1
    done
    ) | dialog --title "Preparando entorno" --gauge "Instalando paquetes..." 8 70 0

}

order () {

    paquetes
    entorno
    ftp
    librerias
    dselinux
    sshc
    seleccionar_puerto
    passwdmod
    cupsconf
    cupsdrivers
    preguntainstalarmysql
    preguntainstalarads
    recomendacao
    exec $SHELL

}
#listo
users-groups () {
    # Agrega el grupo apache si no existe
    groupadd apache > /dev/null 2>&1

    # Crea el usuario cups si no existe
    adduser cups > /dev/null 2>&1
    echo "cups!." | passwd --stdin cups > /dev/null 2>&1

    # Agrega la linea en .bash_profile de cups si no existe
    if ! grep -q "cd /opt/scripts/" /home/cups/.bash_profile; then
        echo "cd /opt/scripts/" >> /home/cups/.bash_profile
    fi
    if ! grep -q "./menu_impresoras.sh" /home/cups/.bash_profile; then
        echo "./menu_impresoras.sh" >> /home/cups/.bash_profile
    fi
    if ! grep -q "logout" /home/cups/.bash_profile; then
        echo "logout" >> /home/cups/.bash_profile
    fi
    
    # Crea el usuario autoapagado si no existe
    adduser autoapagado > /dev/null 2>&1
    echo "autoapagado!." | passwd --stdin autoapagado > /dev/null 2>&1

    # Agrega la linea en .bash_profile de autoapagado si no existe
    if ! grep -q "sudo /sbin/shutdown -h now" /home/autoapagado/.bash_profile; then
        echo "sudo /sbin/shutdown -h now" >> /home/autoapagado/.bash_profile
    fi
    if ! grep -q "logout" /home/autoapagado/.bash_profile; then
        echo "logout" >> /home/autoapagado/.bash_profile
    fi
}

#listo
server-name () {

    NOMBRE="svr-$1"
    hostnamectl set-hostname "$NOMBRE"
    echo "127.0.0.1   $NOMBRE $NOMBRE.localdomain $NOMBRE $NOMBRE.localdomain4" > /etc/hosts
    echo "::1         $NOMBRE $NOMBRE.localdomain $NOMBRE $NOMBRE.localdomain6" >> /etc/hosts

}

name () {

    NOMBRE=$(dialog --clear \
                    --title "Nombre para el servidor" \
                    --inputbox "Por favor, ingrese nombre para el servidor: \nSe le agregara el prefijo svr- al nombre proporcionado ej: \nteste -> svr-teste" 10 70 \
                    2>&1 >/dev/tty)
    if [ -n "$NOMBRE" ]; then
        dialog --clear --title "Nombre para el servidor" --yesno "\nDesea confirmar el siguiente nombre para el servidor?\nsvr-$NOMBRE" 8 70
        respuesta=$?
        case $respuesta in
        0)
            clear
            server-name "$NOMBRE"
            users-groups 
            order
            ;;
        1)
            name
            ;;
        255)
            clear
            ;;
        esac

    else
        menu
    fi

}

menu() {

    local opciones=(
        1 "Instalacion completa."
        2 "Gestor MariaDB."
        3 "Gestor Ads."
        4 "Salir."
    )

    # Muestra el menu y capturar la seleccion del usuario.
    seleccion=$(dialog --clear \
                    --title "INFOSERVE - AUTOINSTALL $DISTRO" \
                    --menu "Seleccione una de las siguientes opciones:" 15 50 4 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)

    # Interpretar la seleccióel usuario
    case $seleccion in
        1) 
            name ;;
        2) 
            menumariadb ;;
        3) 
            menuads ;;
        4) 
            clear ;;
        *) 
            clear ;;
    esac
}
#listo
ejecutar () {

    dialog --clear --title "AUTO-INSTALL INFOSERVE - $DISTRO" --yesno "Desea realizar la instalacion?" 6 50

    respuesta=$?

    case $respuesta in
    0)
        menu
        ;;
    1)
        clear
        ;;
    255)
        clear
        ;;
    esac

}
#listo
consultandodialog() {

    # Verifica si el comando 'dialog' estáisponible en el sistema
    if command -v dialog > /dev/null 2>&1; then
        # Si se encuentra instalado, ejecuta la funcion 'ejecutar'
        ejecutar
    else
        # Si no esta instalado, intenta instalar 'dialog'
        echo -e "\033[36mInstalando dialog...\033[0m"
        $PARAMETRO -y install dialog > /dev/null 2>&1

        # Verifica si la instalacion fue exitosa
        if command -v dialog > /dev/null 2>&1; then
            # Si la instalacióue exitosa, ejecuta la funcióejecutar'
            ejecutar
        else
            # Si la instalacióallóuestra un mensaje de error
            echo "Error al intentar instalar 'dialog'. Por favor, verifica tu conexion o el repositorio."
            exit 1 
        fi
    fi
}

#listo
mensajenointernet () {

    echo -e " ================================================= "
    echo -e "                                                   "
    echo -e "            SIN CONEXION A INTERNET                "
    echo -e "                                                   "
    echo -e "    No se pudo establecer conexion a internet.     "
    echo -e "    * Verifique que el cable de red estéonectado   "
    echo -e "    * Intente utilizar un DNS publico ej: 8.8.8.8  "
    echo -e "    * Si ha modificado la configuracion de la placa"
    echo -e "      de red, reinicie el equipo para aplicar los  "
    echo -e "      cambios y vuelva a intentarlo.               "
    echo -e "                                                   "
    echo -e " ================================================= "


}

#listo
checkinternet () {

    # Comprobando conexion a Internet.
    if ping -c 1 google.com > /dev/null 2>&1; then
        # Si la conexion es exitosa, verifica si 'dialog' estánstalado
        consultandodialog
    else
        # Si no hay conexion, muestra el mensaje y termina
        mensajenointernet
        exit 1  # Sale del script si no hay Internet
    fi
}

mensajedistronocompatible () {

    echo -e " ================================================= "
    echo -e "                                                   "
    echo -e "       SISTEMA OPERATIVO NO COMPATIBLE             "
    echo -e "                                                   "
    echo -e "    La distribucion Linux que estatilizando        "
    echo -e "    no es compatible con este autoinstalador.      "
    echo -e "                                                   "
    echo -e "    Si su sistema es CentOS, se le recomienda      "
    echo -e "        actualizar a Rocky o Alma Linux.           "
    echo -e "                                                   "
    echo -e " ================================================= "
    
}
#listo
distro () {

    # Archivo que contiene el nombre de la distribucion   
    local file="/etc/redhat-release"

    # Verifica si el archivo existe
    if [[ ! -f $file ]]; then
        DISTRO="Desconocida"
        return
    fi

    # Determina la distribucióasáose en el contenido del archivo
    if grep -qi "Rocky" "$file"; then
        DISTRO="Rocky Linux"
        PARAMETRO='dnf'

    elif grep -qi "Alma" "$file"; then
        DISTRO="Alma Linux"
        PARAMETRO='dnf'
    #elif grep -qi "Cent" "$file"; then
    #    DISTRO="Centos Linux"
    #    PARAMETRO='yum'
    else
        DISTRO="Desconocida"
    fi

}
#listo
init () {

    # Comprueba que distribucion de Linux esta instalada
    distro

    # Si la distribucion es desconocida o no compatible, se detiene la instalacion
    if [ "$DISTRO" = "Desconocida" ]; then
        mensajedistronocompatible
        exit 1 # Termina el script si la distribucióo es compatible
    else
        # Si es una distro valida, se verifica la conexion a Internet y se procede con la instalacion       
        checkinternet
    fi

}
#listo
# Verifica si el usuario es ROOT
if [ "$(id -u)" -ne 0 ]; then
    echo -e " ====================================================================== "
    echo -e "                                                                        "
    echo -e "          -> Para poder ejecutar el instalador debe de                  "
    echo -e "                 estar logueado como usuario ROOT.                      "
    echo -e "                                                                        "
    echo -e "                      CERRANDO INSTALADOR...                            "
    echo -e "                                                                        "
    echo -e " ====================================================================== "
    exit 1  # Termina el script si no es ROOT
else
    init  # Si es ROOT, se procede con la instalacion
fi
