#!/bin/bash
echo "0" | ./keygen-ads7 > adsvalidationcode.txt
cat adsvalidationcode.txt| grep  "Serial Number -" | sed 's/.*Serial Number - //' > ./adslinux.intrn-7.10.0/adskey.txt
cat adsvalidationcode.txt | grep "Validation Code" | sed 's/.*Validation Code - //' >> ./adslinux.intrn-7.10.0/adskey.txt
