#!/bin/bash
echo "0" | /opt/install/tools/keygen-ads7 > /opt/install/tools/adsvalidationcode.txt
cat /opt/install/tools/adsvalidationcode.txt| grep  "Serial Number -" | sed 's/.*Serial Number - //' > /opt/install/tools/adslinux.intrn-7.10.0/adskey.txt
cat /opt/install/tools/adsvalidationcode.txt | grep "Validation Code" | sed 's/.*Validation Code - //' >> /opt/install/tools/adslinux.intrn-7.10.0/adskey.txt
