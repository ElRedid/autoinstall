#!/usr/bin/perl -w

# adsdevel.pl

# Copyright 2002, Extended Systems, Inc.
# Script to properly set up permissions and ownership of the data directory
# for Advantage Database Tables

my $datadir = "";  # We'll get this from the user

#print join (", ", @ARGV);

#print (" ", $#ARGV);

if ( $#ARGV == 0 ) #This means that there was one argument provided
{
    if ( $ARGV[0] ne "" )
    {
        $datadir = $ARGV[0];
    }
}

if ( $datadir eq "" )
{
    print "\n This utility will assist you in properly configuring the permissions \n",
          " and ownership of your data directory.  You may run this utility at any time \n",
          " to configure further directories by typing setpermissions.pl.  Enter the full \n",
          " path to your data directory (or press Enter to exit). \n";
    print "\n\nEnter your data directory: ";
    $_ = <STDIN>;
    chomp ($_);
    $datadir = $_;
    if ($datadir eq "")
    {
        exit;
    }
}

#We should now have a directory name with which to work.
#if we want to remove everything after the last slash, use:
#$newdir =~ s/(.*)\/.*$/$1/g;

#Check existence of dir and create if it doesn't exist
if ( not -e $datadir )
{
    $sysret = system ("mkdir $datadir") / 256;
    if ($sysret)
    {
        print( "Failed to create the data directory (error = $sysret).\n",
               " Do you have adequate permissions? \n");
        exit;
    }
}
#Now, the real work:  modify ownership/permissions recursively.
$sysret = system ("chown -R advantage $datadir") / 256;
print( "Failed to change directory owner (error = $sysret).\n",
        " Do you have adequate permissions? \n" ) if $sysret;


$sysret = system ("chmod -R 744 $datadir") / 256;
print( "Failed to change directory permissions (error = $sysret).\n",
        " Do you have adequate permissions? \n") if $sysret;

