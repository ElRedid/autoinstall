#!/bin/bash

# Archivo de configuración
file="setup.ini"

# Leer los valores de adskey.txt
read -r serial_number < <(head -n 1 adskey.txt)
read -r val_code < <(tail -n 1 adskey.txt)

# Actualizar SERIAL_NUMBER en setup.ini
sed -i "s/^SERIAL_NUMBER=.*/SERIAL_NUMBER=$serial_number/" "$file"

# Actualizar VAL_CODE en setup.ini
sed -i "s/^VAL_CODE=.*/VAL_CODE=$val_code/" "$file"