#!/usr/bin/perl -w


# MOD v1
# Copyright 2002-2004, Extended Systems, Inc.
# Install script for ADS for Linux

# TBD - Need to look in existing ads file to see they want to use existing
# serial number.  May go in the C/C++ portion of the install.  This script
# should probably extract the version from the existing file.  If it is
# the same major version as the new binary, then ask user if they want to
# use existing stamped information.  If so then pass the existing binary
# name to the adsstamp binary, which can then do the extraction/transfer.

use strict;         # force variable declarations

use File::Copy;     # for copying files

my $adsfilename = "adsd";       # the file we are installing
my $adsfilename_so = "libadsd.so";
my $adsconfname = "ads.conf";
my $productname = "Advantage Database Server";
my $companyname = "Extended Systems";
my $productversion;          # Pull this from the file being installed

my $acefilename     = "libace.so.7.10.0";
my $aceverlinkname  = "libace.so.7.10";
my $acemainlinkname = "libace.so";

my $myinitscript;

my $setupininame = "setup.ini"; # silent install file name
my $bSilent;        # true if silent install
my $bInternational; # true if international install
my %setupini;       # hash of the silent install section of the setup.ini file
my %adsconf;        # hash of the ads.conf file
my $oemident = "OEM CoLlAtIoN IdEnTiFiEr";
my $ansiident = "ANSICoLlAtIoN IdEnTiFiEr";
my $ownerinfo = "";
my $serialnumber;
my $valcode;
my $authcode;

my $targetdir = "/usr/local/advantage";    # default install location
my $errordir;                              # error log directory
my $licensedir = "/etc/advantage";         # international license directory
my $datadir = "";                                          # destination data directory
my $autostartup = "y";                  # auto startup

my $ansilanguage = "Engl(Amer)";      # the chosen ANSI language
my $oemlanguage = "USA";              # OEM language name
my $locale = "<Default>";             # The specific locale if using machine
                                      # generated collation information.  If
                                      # <Default>, use the environment settings
                                      # as specified in setlocale(3)

my $creatednewdir = 0;                # indicates if we created a new directory
my $creatednewerrordir = 0;           # indicates if we created a new error directory
my $createdlicensedir = 0;            # indicates if we created a new license dir (intern servers)
my $response;                         # temp variable
my @stampcmd;     
my @copia;                    # command for stamping the binary


# Change working directory to location of this script (since that is where
# the files we are dealing with should be)
my $newdir = $0;                  # get the command line that started the script
$newdir =~ s/(.*)\/.*$/$1/g;      # remove from last slash to end of string
if ( $newdir ne $0 )     # if it happens to just be an unadorned name, don't do anything
   {
   #
   chdir( $newdir ) || die( "Unable to change working directory to location of install script: $!" );
   }

# slurp up the contents of the setup.ini section of interest
%setupini = ReadINISection( $setupininame, "silent_install" );

# Determine if it is a silent install
$bSilent = CheckIfSilentInstall();



# get the version number
$productversion = ExtractInternalVersion( $adsfilename_so );


ClearScreen() if !$bSilent;

printf( "\nThis will install " . $productname . " " . $productversion . "\n" ) if ( ! $bSilent );
pp( "\nYou may need to log in as root in order to complete the installation ".
    "process.  For example, you may need root permissions to copy the Advantage ".
    "Database Server daemon to its target location.  In addition, root permissions ".
    "may be needed to add the advantage user and group if they do not already ".
    "exist." ) if ( `whoami 2>/dev/null` !~ /^root$/ ) && !$bSilent;


# Determine if it is an international install
$bInternational = CheckIfInternational();

# set default ansi language to be "default" if international
$ansilanguage = "<Default>" if $bInternational;


# Get the answers (if it's a silent install, it won't prompt)
PromptForInstallInfo();


# make the target directories
$creatednewdir = CreateDirectory( $targetdir );
$creatednewerrordir = CreateDirectory( $errordir );
$myinitscript = CreateDirectory( $targetdir . "/script" );

# If international server make the license directory
if ( $bInternational )
   {
   $createdlicensedir = CreateDirectory( $licensedir );
   }

# see if there is enough space
CheckDiskSpace( $targetdir );

# Make copies of the existing files
BackupFiles();


ClearScreen() if !$bSilent;

# build up the stamp command
BuildStampCommand();


# Copy the daemon to the target location
CopyFilesToDestination();

# Set up the help file index html file
CreateMainHelp( $targetdir );

SetLinks();

###
CreateUserGroup();

# Now stamp the information into the file

system("echo '---------->Para activar el ADS<----------'");
system("echo '--> Seleccione la opcion 3 Register over the phone'");
system("echo 'Ingrese el siguiente codigo:'");
system("./validation.sh");

my $sysret = system(@stampcmd);

if ( $sysret )
   {
   pp( "\nAn error occurred while stamping the daemon.  It will not be copied to the target directory." );
   exit 1;
   }



# Create advantage user and group if necessary
### CreateUserGroup();

# In general, we want the owner and group of the install directory, the error
# log directory, and the ads.conf file to be "advantage".  adsd runs with
# with the advantage group ID.  For example, to be able to write error logs, it
# must have permissions to the error log directory.  So if we create a new
# directory, we simply set the ownership to advantage.  If the error log directory
# already exists, just tell them they need to make sure advantage has permissions
# to write to that directory.

# Set the ownership of the install directory to advantage
SetFileOwnership( $creatednewdir, $targetdir );

# Set the ownership of the log directory
SetFileOwnership( $creatednewerrordir, $errordir );

# Set the ownership of the license directory
SetFileOwnership( $createdlicensedir, $licensedir );

# Set the ownership of the script directory
SetFileOwnership( $creatednewdir, $targetdir );

# If we didn't create the directory, then give the warning message
pp( "\nIn order for the Advantage Database Server to be able to write to " .
    "its error log files, please make sure that the advantage user has " .
    "permissions to write to the $errordir directory.  " .
    " Alternatively, you can specify a different error log path " .
    "in the ads.conf file. " ) if !$bSilent && !$creatednewerrordir;


# Set the ownership of the conf file.  (the 1 essentially means do it)
SetFileOwnership( 1, "$targetdir/$adsconfname" );


#Set data directory permissions.
%setupini=ReadINISection($setupininame, "silent_install");
$datadir = $setupini{ "data_directory" };
system ( "./setpermissions.pl $datadir" );


#Configure ADS for startup as a system service
ConfigureForStartup();

# All done
pp( "\nThe $productname installation is complete.  Start the daemon by running " .
    "$targetdir/$adsfilename or by adding it to the appropriate startup script." ) if !$bSilent;

# Documentation Note
pp( "\nNOTE:  HTML documentation can be found in $targetdir/doc/index.html. " ) if !$bSilent;


# Clear the screen
sub ClearScreen
{
   # this evaluates the "clear" command
   system( "clear" );
}



# Change ownership of the install directory to "advantage" if we created it.
sub  SetFileOwnership
{
   my ( $creatednew, $location ) = @_;

   if ( $creatednew )
      {
      # We created a new directory, get the uid/gid of the advantage user
      # and change the owner and group of the install directory
      my $uid = getpwnam( "advantage" );
      my $gid = getgrnam( "advantage" );

      if ( !$uid || !$gid )
         {
         pp( "\nFailed to retrieve group information for the advantage user. " .
             "The ownership of the directory $location will not be " .
             "changed to advantage.  You should manually change the user and " .
             "group of $location to advantage. " );
         }
      else
         {
         # try to change the ownership
         my $cnt = chown( $uid, $gid, $location );

         if ( $cnt == 0 )
            {
            pp( "\nFailed to change the owner and group for " .
                "$location. You should manually change the user and " .
                "group of $location to advantage. " );
            }
         }
      }  # if new directory


}  # SetFileOwnership



# If the advantage user and group don't exist, try to add them
sub CreateUserGroup
{

   # Create the Advantage user group and user if they don't already exist
   if ( !FileHasString( "/etc/group", "^advantage:" ))
      {
      if ( `which groupadd 2>/dev/null` eq "" )
         {
         # They apparently don't have the groupadd command in the path (probably
         # means they are not root).
         pp( "\nYou do not have permissions to run the groupadd command.  The ".
             "advantage group will not be created. " );
         }
      else
         {
         $sysret = system( "groupadd advantage" );
         printf( "Failed to add the advantage group account (error = %d).\n", $sysret / 256 ) if $sysret;
         }
      }

   # Now the user
   if ( !FileHasString( "/etc/passwd", "^advantage:" ))
      {
      if ( `which useradd 2>/dev/null` eq "" )
         {
         # They apparently don't have the groupadd command in the path (probably
         # means they are not root).
         pp( "\nYou do not have permissions to run the useradd command.  The ".
             "advantage user will not be created. " );
         }
      else
         {
         $sysret = system( "useradd advantage -g advantage -c 'Advantage Database Server'" );
         printf( "Failed to add the advantage user (error = %d).\n", $sysret / 256 ) if $sysret;
         }
      }
}  # CreateUserGroup




# Fill in the global @stampcmd list with the stamp command and appropriate params
sub BuildStampCommand
{
   my $ac = 0;  # arg count

   $stampcmd[$ac++] = "./adsstamp";      # program name
   $stampcmd[$ac++] = "$targetdir/$adsfilename_so";    # the file name we are stamping

   $stampcmd[$ac++] =  "-prompt" if !$bSilent;

   if ( -e "$targetdir/$adsfilename_so.old" )
      {
      $stampcmd[$ac++] = "-old";
      $stampcmd[$ac++] = "$targetdir/$adsfilename_so.old";
      }

   if ( $serialnumber )
      {
      $stampcmd[$ac++] = "-serial";
      $stampcmd[$ac++] = $serialnumber;
      }

   if ( $valcode )
      {
      $stampcmd[$ac++] = "-valcode";
      $stampcmd[$ac++] = $valcode;
      }

   if ( $authcode )
      {
      $stampcmd[$ac++] = "-authcode";
      $stampcmd[$ac++] = $authcode;
      }

   if ( $ownerinfo )
      {
      $stampcmd[$ac++] = "-owner";
      $stampcmd[$ac++] = $ownerinfo;
      }

   if ( $ansilanguage )
      {
      $stampcmd[$ac++] = "-ansi";
      $stampcmd[$ac++] = $ansilanguage;
      }

   if ( $oemlanguage )
      {
      $stampcmd[$ac++] = "-oem";
      $stampcmd[$ac++] = $oemlanguage;
      }

   if ( $locale )
      {
      $stampcmd[$ac++] = "-locale";
      $stampcmd[$ac++] = $locale;
      }
}  # BuildStampCommand


# Extract the version information from the given file name using the ident
# string stored in Advantage binaries.
sub ExtractInternalVersion
{
   my ($filename) = @_;

   my $ver;

   # search for it in the file
   $ver = FileHasString( $filename, "EsIAx!@#" );

   # bail if we didn't find it
   if ( !$ver )
      {
      printf( "\nWarning - The internal version number was not found in $filename\n\n" );
      return "";
      }

   # we now have a long string of junk that contains the string in the middle
   # of it.  Extract it from the string.  The part we want is the ([\w\.]+)
   # portion which finds all text of alphanumeric characters and "."s following
   # the ident string.
   $ver =~ s/(.*EsIAx!@# )([\w\. ]+)(.*)/$2/;
   chomp( $ver );

   return $ver;
}  # ExtractInternalVersion



# This prompts for user input.  It just fills in the global variables
sub PromptForInstallInfo
{

   my $bDone = 0;
   my $bDone2 = 0;

   # Grab the registration info out of the ini file.  If it exists, we simply
   # use it for the stamp command.  That is primarily for beta releases so we
   # can put an authcode in the ini file and people don't get prompt for it.
   # Kind of a psuedo-silent install.
   $ownerinfo = $setupini{ "registered_owner" };
   $authcode = $setupini{ "auth_code" };
   $serialnumber = $setupini{ "serial_number" };
   $valcode = $setupini{ "val_code" };

   while ( !$bDone )
      {
      $bDone = 1;
      $bDone2 = 0;

      # Get registration information
      if ( !$bSilent )
         {
         # prompt for the  owner.  The stamp exe will actually prompt for the
         # serial number and valcode/authcode.
         print "\nEnter the registered owner's name: ";
         # tack on current value if it is set
         print " ($ownerinfo) " if $ownerinfo;
         $_ = <STDIN>;
         chomp ($_);
         $ownerinfo = $_ if ( $_ ne "" );
         }


      # Target directory for ads
      #if ( $bSilent )
      #   {
      #   $targetdir = $setupini{ "application_path" };
      #   }
      #else
      #   {
      #   print "\nEnter the destination path: ($targetdir) ";
      #   $_ = <STDIN>;
      #   chomp ($_);
      #   $targetdir = $_ if ( $_ ne "" );
      #   }

      # Error log directory for ads
      if ( $bSilent )
         {
         $errordir = $setupini{ "error_assert_logs" };
         }
      else
         {
         # If we haven't yet initialized the error dir, read it out of the
         # ads.conf file.  If there is an existing conf file in the target
         # directory, read it from there.
         if ( !$errordir )
            {

            if ( -e "$targetdir/$adsconfname" )
               {
               # found it in the target directory, read that one
               %adsconf = ReadINISection( "$targetdir/$adsconfname", "" );
               }
            else
               {
               # use the new ads.conf - apparently a new install
               %adsconf = ReadINISection( $adsconfname, "" );
               }

            $errordir = $adsconf{ "error_assert_logs" };

            # If still empty, set it to the default
            if ( !$errordir || $errordir eq "" )
               {
               $errordir = "/var/log/advantage";
               }

            }  # if error dir not initialized


         #print "\nEnter the error log path: ($errordir) ";
         #$_ = <STDIN>;
         #chomp ($_);
         #$errordir = $_ if ( $_ ne "" );
         }  # else not silent


      # Get the language (character set) information
      if ( $bSilent )
         {
         $ansilanguage = $setupini{ "ansi_language" };
         $oemlanguage = $setupini{ "oem_language" };
         $locale = $setupini{ "locale" };
         }
      else
         {
         if ( $bInternational )
            {
            PromptForIntlLanguages();
            }
         else
            {
            PromptForDomesticLanguages();
            }
         }

      # Query for Automatic startup
      if ( $bSilent )
         {
         $autostartup = $setupini{ "auto_startup" };
         }
      else  # !silent
         {
         ClearScreen();

         while ( !$bDone2 )
            {
            $bDone2 = 1;

            #pp( "This script can add ADS to your system startup scripts.  If you " .
            #    "answer 'y' below, it will copy the adsd script to the /etc/init.d " .
            #    "directory, then call chkconfig.  Do not answer 'y' unless you " .
            #    "know that this will work on your system.  (This should work for " .
            #    "any RedHat or Mandrake distribution, as well as any others that " .
            #    "use the same method to configure a service for automatic startup.) \n" );

            #print "\nWould you like ADS to be added to your startup scripts? [yn] ($autostartup): ";
            #$_ = <STDIN>;
            #chomp ($_);
            #$autostartup = $_ if ( $_ ne "" );

            $bDone2 = 0 if ( $autostartup !~ /^y|n/i )
            }
         }

      # Show them their choices and let them change it if desired
      if ( !$bSilent )
         {
         ClearScreen();
         print "\nThese are the current install selections:\n";
         print "   Registered owner: $ownerinfo\n";
         print "   Destination path: $targetdir\n";
         print "   Error log path: $errordir\n";
         print "   ANSI Language: $ansilanguage\n" if ( $ansilanguage !~ /default/i );
         print "   Automatic Startup: $autostartup\n";

         if ( $bInternational )
            {
            print "   Locale for default character set generation: $locale\n" if  ( $ansilanguage =~ /default/i );
            print "   OEM Language: $oemlanguage\n";
            }
         print "\nDo you want to change any choices? [yn](n): ";
         $bDone = 0 if ( <STDIN> =~ /^y/i )
         }
      }  # while not done

}  # PromptForInstallInfo


# stupid function to write a "paragraph" to stdout with word wrapping at
# 72 characters.  There are probably clever/cool/weird ways to do this in
# perl, but I don't know them.  I read in a couple NG posts that you can
# just use formats which will do the word wrapping.  Any format I tried,
# though, just truncated the text or broke at the end of the terminal screen.
# as in "print paragraph"  (it's lame but short)
sub pp     
{
   my ( $longtext ) = @_;

   # put a space on the end - otherwise it sometimes wraps the last word
   $longtext = $longtext . " ";

   # Wrap at 72 chars - This is from a David Bell '96 news group post.
   $longtext =~ s/(.{1,72})\s+/$1\n/g;

   print $longtext;
}



# Read the available character set names from ansi.chr and return them in an array
sub ReadANSINames
{
   my @charsets;   # return value
   my $name;       # current character set name
   my $inuse;      # inuse flag for the character set
   my $offset;     # offset of character set in file
   # This defines the "record" of a header value
   my $recformat = 'C A11 L';   # Unsigned character, 11 byte name, 4 byte offset
   my $recwidth  = 16;          # width of a record
   my $i;
   my $rec;        # The raw record
   my $numrecs = 25; # The current ansi.chr has up to 25 character sets
   my $totalsets = 0;

   open( CHARSET, "ansi.chr" ) || die "Unable to open ansi.chr:  $!";

   for ( $i = 0; $i < $numrecs; $i++ )
      {
      # read the raw record from the table
      read( CHARSET, $rec, $recwidth ) == $recwidth || die "Unable to read record $i from ansi.chr: $!";

      # unpack the record into usable variables
      ($inuse, $name, $offset) = unpack( $recformat, $rec );

      # if it is in use, add it to the array
      $charsets[$totalsets++] = $name if $inuse;
      }

   close( CHARSET );

   return @charsets;

}  # ReadANSINames


# Read the available character set names from extend.chr and return them in an array
# Pretty much identical to the above routine to read the ansi names.  It could
# be a single function with some parameters, but I'm lazy.
sub ReadOEMNames
{
   my @charsets;   # return value
   my $name;       # current character set name
   my $inuse;      # inuse flag for the character set
   my $offset;     # offset of character set in file
   # This defines the "record" of a header value
   my $recformat = 'C A9 L';   # Unsigned character, 9 byte name, 4 byte offset
   my $recwidth  = 14;         # width of a record
   my $i;
   my $rec;        # The raw record
   my $numrecs = 50; # The current ansi.chr has up to 25 character sets
   my $totalsets = 0;

   open( CHARSET, "extend.chr" ) || die "Unable to open extend.chr:  $!";

   for ( $i = 0; $i < $numrecs; $i++ )
      {
      # read the raw record from the table
      read( CHARSET, $rec, $recwidth ) == $recwidth || die "Unable to read record $i from ansi.chr: $!";

      # unpack the record into usable variables
      ($inuse, $name, $offset) = unpack( $recformat, $rec );

      # if it is in use, add it to the array
      $charsets[$totalsets++] = $name if $inuse;
      }

   close( CHARSET );

   return @charsets;

}  # ReadOEMNames



# Given a list of names and a response, check to see if the response is in
# the list (or is a valid numeric 1 based reference to an item in the list).
# The obvious way (to me) of doing this is to pass the response by reference
# and change the value.  I wasn't smart enough to make that work, so I return
# two values from the function, which in itself is a pretty cool concept.
sub CheckListResponse
{
   my ( $response, @choices ) = @_;

   my $validanswer = 0;
   my $index;


   printf "!!! Test:  %s, response = %s\n", $choices[6], $response ;

   if ( $response =~ /^[\d]+$/ )
      {
      # They chose a numeric value
      if ( $response > 0 && $response <= @choices )
         {
         $response = $choices[$response - 1];
         $validanswer = 1;
         }
      }  # if numeric input
   else
      {
      # apparently typed in a name - make sure it is in the list
      for ( $index = 0; $index < @choices; $index++ )
         {
         if ( $response =~ /$choices[$index]/i )
            {
            $response = $choices[$index];
            $validanswer = 1;
            last;
            }
         }
      }

   # return the two values in a list
   return ( $validanswer, $response );

}  # CheckListResponse




# Prompt the user for which language from the ansi.chr and extend.chr files
# they want.  This is for international installs.
sub PromptForIntlLanguages
{
   my @ansicharsetnames;     # array of character set names from ansi.chr
   my @oemcharsetnames;      # array of character set names from extend.chr
   my $index;
   my $validanswer;          # true/false
   my $response;             # the response from the user



   # Make sure the ansi.chr exists
   if ( -e "ansi.chr" )
      {
      @ansicharsetnames = ReadANSINames();
      }
   else
      {
      # This shouldn't happen - if it does, it means that they will have to
      # choose <Default> as the ansi language and we will generate a collation
      # language for them.
      pp "\nWarning:  The file ansi.chr does not exist.  The installation should " .
         "have included this file.  You will have to allow the installation " .
         "program to generate the ANSI character set.";
      printf( "\nPress <enter> to continue " );
      <STDIN>;
      }


   # make sure extend.chr exists
   if ( -e "extend.chr" )
      {
      @oemcharsetnames = ReadOEMNames();
      }
   else
      {
      # This shouldn't happen - The script uses the existence of extend.chr as
      # part of the decision that this is an international install, which is
      # the only way we should get to this routine.  So something is goofed up.
      pp "Warning.  The extend.chr file does not exist.  The installation should " .
         " have included this file.  It is required to complete the installation.\n";
      exit 1;
      }


   # Need to prompt for the information
   #$validanswer = 0;
   #ClearScreen();

   #while ( !$validanswer )
      #{

      # Get the ANSI language
      #pp( "\nPlease select an ANSI character set to use with the Advantage " .
      #    "Database Server." );
      #pp( "\nIf <Default> is chosen, the installation program will generate ".
      #    "a character set to use based on a locale that you can choose." );
      #pp( "\nSelecting a specific ANSI language for all Advantage installs " .
      #    "(including Local Server) will guarantee the ANSI character sets " .
      #    "used by all Advantage applications will be the same." );
      #pp( "\nThis setting does not apply to tables opened with OEM as the ".
      #    "specified character set type or to Advantage DOS applications." );

      #printf( "%5d - %s\n", 0, "<Default>" );
      #for ( $index = 0; $index < @ansicharsetnames; $index++ )
      #   {
      #   printf( "%5d - %s\n", $index + 1, $ansicharsetnames[$index] );
      #   }
      #print "\nPlease select a language: ($ansilanguage) ";
      #$response = <STDIN>;
      #chomp( $response );

      #if ( $response eq "" )
      #   {
         # No change - leave ansi language the same
      #   $validanswer = 1;
      #   }
      #else
      #   {
         # Now make sure they entered a valid value
      #   if ( $response =~ /^0$|default/i )
      #      {
            # They chose default
      #      $ansilanguage = "<Default>";
      #      $validanswer = 1;
      #      }
      #   else
      #      {
            # Something other than default - extract the result - pass the
            # list and the response to this function.  It returns the boolean
            # indicating if it is valid and the converted response value if
            # it is valid.
      #      ( $validanswer, $response ) = CheckListResponse( $response, @ansicharsetnames );

      #      $ansilanguage = $response if $validanswer;

      #      }  # else not default
      #   }  # else response entered

      #if ( !$validanswer )
      #   {
      #   ClearScreen();
      #   pp( "\nYour choice was not valid.  Please enter a numeric value from " .
      #       "the list or type the desired name." );
      #   }

      #}  # while not valid ansicharset


      # If the chose <default>, need to request a locale.
      #if ( $ansilanguage =~ /default/i )
      #   {
      #   ClearScreen();
      #   pp( "\nSince you chose $ansilanguage for the ANSI language, you can provide " .
      #       "a locale setting that will be used to generate the character set. " .
      #       "The valid locale values differ by workstation and depend on the " .
      #       "specific Linux installation.  The actual locale definitions are " .
      #       "usually stored in /usr/share/i18n/locales. " .
      #       "If you specify <Default>, the current environment settings ".
      #       "(e.g., LC_ALL, LC_COLLATE, and LANG) are used. ".
      #       "See the locale(5) and setlocale(3) manpages for more information. " );

      #   print "\nPlease enter the locale: ($locale) ";

      #   $_ = <STDIN>;
      #   chomp ($_);
      #   $locale = $_ if $_ ne "";

      #   # convert to <Default> for consistency if needed
      #   $locale = "<Default>" if $locale =~ /default/i;
      #   }
     


   # prompt for OEM language
   $validanswer = 0;
   ClearScreen();

#   while ( !$validanswer )
#      {
#      pp( "\nPlease select an OEM character set to use on the Advantage " .
#          "Database Server.  " .
#          "The OEM character set is necessary only if your Advantage application " .
#          "uses OEM/Localized character sets." );
#      pp( "\nThe Advantage Database Server supports the following OEM/Localized " .
#          "character sets.  Please select the set that matches your Advantage " .
#          "client applications." );
#      pp( "\nSelecting a specific OEM/Localized character set for all Advantage " .
#          "installs (including Local Server) will guarantee the OEM/Localized " .
#          "character sets used by all Advantage applications will be the same." );
#
#      for ( $index = 0; $index < @oemcharsetnames; $index++ )
#         {
#         printf( "%5d - %s\n", $index + 1, $oemcharsetnames[$index] );
#         }
#
#      print "\nPlease select a language: ($oemlanguage) ";
#      $response = <STDIN>;
#      chomp( $response );
#
#      # if no response, just use the existing contents of the oemlang variable
#      $response = $oemlanguage if $response eq "";
#
#      # make sure the response is in the list of available choices
#      ( $validanswer, $response ) = CheckListResponse( $response, @oemcharsetnames );
#
#      # assign the response if it was valid
#      $oemlanguage = $response if $validanswer;
#
#      if ( !$validanswer )
#         {
#         ClearScreen();
#         pp( "\nYour choice was not valid.  Please enter a numeric value from " .
#             "the list or type the desired name." );
#         }
#
#      }  # while not valid oem response
#
}  # PromptForIntlLanguages


# For domestic install, we allow basically two choices for the ANSI language.
# We allow "USA" and French Canadian.  We do not support an OEM character set
# in the domestic server.
sub PromptForDomesticLanguages
{
   my @ansicharsetnames;     # array of allowed character set names
   my $index;
   my $validanswer;          # true/false
   my $response;             # the response from the user



   # Don't need ansi.chr for domestic install.  The stamp program has the
   # French Canadian character set hard-coded.

   # give the available choices (the two ENGL's are the same internally)
   @ansicharsetnames = ( "Engl(Amer)", "Engl(Can)", "French Can" );


   # Need to prompt for the information
   $validanswer = 0;
   ClearScreen();

   #   while ( !$validanswer )
   #      {
   #
   #      # Get the ANSI language
   #      pp( "\nPlease select an ANSI character set to use on the Advantage " .
   #          "Database Server." );
   #      pp( "\nThe USA version of the Advantage Database Server supports ".
   #          "English (United States) and Canadian languages.  If a different ANSI ".
   #          "language is desired, the non-USA version of the Advantage Database ".
   #          "Server must be installed." );
   #      pp( "\nSelecting a specific ANSI language for all Advantage installs " .
   #          "(including Local Server) will guarantee the ANSI character sets " .
   #          "used by all Advantage applications will be the same." );
   #      pp( "\nThis setting does not apply to tables opened with OEM as the ".
   #          "specified character set type or to Advantage DOS applications." );

   #      for ( $index = 0; $index < @ansicharsetnames; $index++ )
   #         {
   #         printf( "%5d - %s\n", $index + 1, $ansicharsetnames[$index] );
   #         }
   #      print "\nPlease select a language: ($ansilanguage) ";
   #      $response = <STDIN>;
   #      chomp( $response );

   #      if ( $response eq "" )
   #         {
         # No change - leave ansi language the same
   #         $validanswer = 1;
   #         }
   #      else
   #         {
   #         # check the validity
   #         ( $validanswer, $response ) = CheckListResponse( $response, @ansicharsetnames );
   #
   #         $ansilanguage = $response if $validanswer;
   #
   #         }  # else response entered
   #
   #      if ( !$validanswer )
   #         {
   #         ClearScreen();
   #         pp( "\nYour choice was not valid.  Please enter a numeric value from " .
   #             "the list or type the desired name." );
   #         }

   #      }  # while not valid ansicharset


}  # PromptForDomesticLanguages


# copy a file
sub CopyFile
{
   # Get the parameters:  source file, destination file, desired permissions
   my ( $source, $dest, $permissions ) = @_;

   my $origmtime;
   my $origatime;

   # extract time/date info to restore after the copy (want 8th and 9th params of stat)
   ($origatime, $origmtime) = ( stat( $source ))[8, 9];

   # copy the daemon
   copy( $source, $dest ) ||
                die  "Failed to copy $source to $dest.  Please verify that you have the correct permissions:  $!";

   # Make it executable by the owner
   chmod( $permissions, $dest );

   # restore the time
   utime( $origatime, $origmtime, "$dest" );
}



# Copy a directory tree to given location starting with the given subdirectory
sub CopySubdirectory
{

   my ( $curdir, $dest ) = @_;

   my @files;
   my $file;

   # Create the target directory
   CreateDirectory( "$dest/$curdir" );

   # Now copy each file in this directory
   @files = glob( "$curdir/*" );
   foreach $file ( @files )
      {
      if ( -d $file )
         {
         # This is a directory - copy it
         CopySubdirectory( $file, $dest );
         }
      else
         {
         # copy the single file
         CopyFile( $file, "$dest/$file", 0644 );
         }
      }  # for each file

}  # CopySubdirectory


# Copy the files to the destination location
sub CopyFilesToDestination
{
   my $origmtime;
   my $origatime;
   my %newadsconf;
   my %oldadsconf;

   printf( "Copying files...\n" ) if !$bSilent;

   # copy the binary
   CopyFile( $adsfilename, "$targetdir/$adsfilename", 0744 );
   CopyFile( $adsfilename_so, "$targetdir/$adsfilename_so", 0444 );

   CopyFile( "LICENSE", "$targetdir/LICENSE", 0644 );
   CopyFile( "README", "$targetdir/README", 0644 );

   CopyFile( "adsscript", "$targetdir/script/ads", 0644 );

   # copy adsstamp binary, a few customers have asked for this
   CopyFile( "adsstamp", "$targetdir/adsstamp", 0744 );

   # configure ads startup file to point to the deamon at the right place
   ConfigureStartupFile( "/usr/local/advantage/",
                         $targetdir . "/" );

   # install the help files
   system( "tar -zxf help.tar.gz -C$targetdir" );

   CopyFile( $acefilename, "/usr/lib/$acefilename", 0744 );

   # Do the conf file copy/merge

   # extract time/date info of ads conf file
   ($origatime, $origmtime) = ( stat( $adsconfname ))[8, 9];

   # At this point, we have the new ads.conf file and possibly the original ads.conf
   # in the target directory (renamed as ads.conf.old).  In addition, we have
   # the error log directory from the user that might be different.  We need to
   # merge all this stuff together into a single glorious ads.conf.
   # The method for doing the merging is pretty much brute force - slurp up the
   # contents of the files into hash variables and then print out the new file.
   if ( -e "$targetdir/$adsconfname.old" )
      {
      # There is an existing file
      %oldadsconf = ReadINISection( "$targetdir/$adsconfname.old", "" );
      %newadsconf = ReadINISection( $adsconfname, "" );

      # Store the user-specified (or setup.ini specified) error log directory
      # value in the old conf file hash so it will get precedence
      $oldadsconf{ "error_assert_logs" } = $errordir;

      # combine the two (pass the hashes by reference)
      MergeConfFiles( \%oldadsconf, \%newadsconf );
      }
   else
      {
      # there is just the new conf file
      %newadsconf = ReadINISection( $adsconfname, "" );

      # update the error directory in case they changed it
      $newadsconf{ "error_assert_logs" } = $errordir;
      }


   # Write out the shiny new conf file
   WriteConfFile( "$targetdir/$adsconfname", %newadsconf );

   # set the modification times on the file to the install version
   utime( $origatime, $origmtime, "$targetdir/$adsconfname" );


   ClearScreen() if !$bSilent;

}  # CopyFilesToDestination



# write out the given ads conf file
sub WriteConfFile
{
   my ( $filename, %newconf ) = @_;


   # try to open the file for output.  Not sure if this should be a fatal
   # error.  If we got this far (we were able to copy files into the directory
   # where we are trying to write to), then I'm not sure what would cause
   # the failure, but it seems unlikely that anything good is happening, so
   # just die for now.
   open( CONFFILE, "> $filename" ) || die "Unable to open $filename:  $!";


   # Loop through the entries in the order we read them
   my $current = 1;
   my $key;

   while ( 1 )
      {
      # bail out if there are no more entries
      last if !$newconf{ "$current" };

      $key = $newconf{ "$current" };

      # print the comment to the file
      printf( CONFFILE "%s", $newconf{ "$key.comment" } );

      # print the key/value (key in upper case)
      printf( CONFFILE "%s=%s\n", uc( $key ), $newconf{ "$key" } );

      $current++;
      }  # while


   close( CONFFILE );

}  # WriteConfFile



# Merge two ads.conf files that are stored in the hash produced by the
# ReadIniSection code.  All this does is takes every key/value pair for
# actual entries from the old hash and stores them in the new hash (presumably
# overwriting the existing value).  The hash actually has three entries for
# every conf file entry.  It has the key/value.  But it also has a key.comment/comment
# entry and an n/key entry for ordering.
#
# If there is a value in the old file that is not in the new file, don't copy it
# because it is apparently obsolete.
sub MergeConfFiles
{
   # the hashes are expected to be passed by reference.  The second one
   # is the new file (it is modified in place)
   my ($oldconfref, $newconfref) = @_;


   # A couple ways come to mind to do this.  One is to simply do a "foreach" for
   # all entries in the hash and ignore the "key.comment" and "n" keys.  The
   # other way (the one I'm using) is to loop 1 to n until we run past the end
   # of the "n" keys.

   my $current = 1;
   my $key;
   my $value;

   while ( 1 )
      {
      # bail out if there are no more entries
      last if !$oldconfref->{ "$current" };

      $key = $oldconfref->{ "$current" };
      $value = $oldconfref->{ "$key" };

      # store it in the new conf (if it already exists)
      $newconfref->{ "$key" } = $value if defined( $newconfref->{ "$key" } );

      $current++;
      }  # while

} # MergeConfFiles



# Backup any existing files in the target directory that we plan to overwrite
# This uses the global variables directly
sub BackupFiles
{

   if ( -e "$targetdir/$adsfilename" )
      {
      # Attempt to rename the existing binary
      rename( "$targetdir/$adsfilename", "$targetdir/$adsfilename.old" )
                 || die "Unable to rename existing $targetdir/$adsfilename to $targetdir/$adsfilename.old: $!";
      }

   if ( -e "$targetdir/$adsfilename_so" )
      {
      # Attempt to rename the existing binary
      rename( "$targetdir/$adsfilename_so", "$targetdir/$adsfilename_so.old" )
                 || die "Unable to rename existing $targetdir/$adsfilename_so to $targetdir/$adsfilename_so.old: $!";
      }

   if ( -e "$targetdir/$adsconfname" )
      {
      # And rename the config file
      rename( "$targetdir/$adsconfname", "$targetdir/$adsconfname.old" )
                 || die "Unable to rename $targetdir/$adsconfname to $targetdir/$adsconfname.old:  $!";
      }

}  # BackupFiles



# Create the given directory if it does not exist.  Return 1/0 indicating if
# we did create the new directory.
sub CreateDirectory
{
   my ($location) = @_;

   if ( ! -d $location )
      {
      # use the system mkdir command because it will create parent directories
      # if needed.
      my $sysret = system( "mkdir -p $location" );
      if ( $sysret != 0 )
         {
         $sysret /= 256;  # documentation says it must be divided by 256 for true code
         die "Unable to create the directory $location.  Make sure you have the correct permissions.  Error code = $sysret";
         }

      # set the permissions so that users can see and traverse the directory
      chmod( 0755, $location );

      return 1;
      }

   # did not create a new directory
   return 0;

}  # CreateDirectory




# Check for the amount of disk space
sub CheckDiskSpace
{
   my ($location) = @_;

   unless ( open ( DF, "df -k $location|" ) )
      {
      printf ( "Unable to get disk space information for $location.  Error is $!\n" );
      return;
      }

   while ( <DF> )
      {
      if ( /No such file/ )
         {
         printf( "Unable to get disk space information for $location.\n" );
         return;
         }

      # TBD - do we really need this information?  If so, we can parse the
      # output of this command and look for the amount of space left and
      # compare it to the various file sizes.  (adsd and the backup files
      # we may make).  The alternative is that the install will fail somewhere
      # along the line with a fairly obvious error any way.
      }

   close( DF );
}  # CheckDiskSpace


# Determine if this is an international install
sub CheckIfInternational
{
my $bRet = 0;
my $bHasIdent = 0;
my $bExtendExists = 0;

   # With the NT and NLM install, we simply check to see if extend.chr (the file
   # with the OEM char sets) exists.  If so, we assume international.  Here I
   # am checking to see if the magical collation ident exists in the file as
   # well as if extend.chr exists.

   $bExtendExists = 1 if ( -e "extend.chr" );

   $bHasIdent = 1 if ( FileHasString( $adsfilename_so, $oemident ));

   # Give a warning for a couple cases
   if ( $bExtendExists && !$bHasIdent )
      {
      pp( "\nWarning:  The OEM character set extend.chr exists, but the ADS " .
          " binary does not have OEM character set support." ) if !$bSilent;
      }

   if ( !$bExtendExists && $bHasIdent )
      {
      pp( "\nWarning:  The ADS binary has OEM character set support, but the OEM character set extend.chr file does not exist." );
      }

   $bRet = 1 if ( $bExtendExists && $bHasIdent );

   return $bRet;

}  # CheckIfInternational




# Search a file for the existence of a string.  Return the string if found.
sub FileHasString
{
   my ( $filename, $search ) = @_;

   my $hasstring = 0;


   open( SEARCHFILE, $filename ) || die "Unable to open $filename:  $!";

   while ( <SEARCHFILE> )
      {
      if ( /$search/ )
         {
         $hasstring = $_;
         last;
         }
      }

   close( SEARCHFILE );

   return $hasstring;
}  # FileHasString


# Look in the setup.ini file info to see if they want a silent install
# Returns 1 if silent install, 0 if not
sub CheckIfSilentInstall
{
my $bRet;


   $bRet = 1;   # assume silent unless we don't find the values we expect

   # The setupini hash already has been read.
   # Currently, all we require is the application path to be considered a
   # silent install (same as NT install)
   if ( ! $setupini{ "application_path" } )
      {
      # not in there or not set - so it is a "noisy" install
      $bRet = 0;
      }


   return $bRet;
}  # CheckIfSilentInstall





# Slurp in a section of an INI style file.  It returns a hash
# of the key/value pairs.
# Input params are the filename and the section to read
# The section (second parameter) can be empty in which case it just starts
# reading pairs at the top and quit if it runs into a section.
#
# NOTE - all key names are converted to lower case.
#
# As it reads the file it puts all comment/whitespace stuff into the hash
# as well as the entries.  The assumption is that the comments precede the
# entry.  If the entry is something like "thing=stuff", then the hash will
# contain the key "thing" with value "stuff" and a key named "thing.comments"
# with all the lines of comments preceding the entry.
#
# This also kludges in a method for extracting the values from the hash in
# the order we read them.  It adds a hash entry of the form "number"/"key".  So
# if the above example "thing=stuff" was the first entry.  There will be a
# "1"/"thing" entry in the hash.
#
# All of this probably constitutes severe hash-abuse, but the files we are
# dealing with are reasonably small, so it should be pretty fast.
sub ReadINISection
{
   # assign params
   my ( $filename, $section ) = @_;

   my %pairs;     # hash of key/value pairs  (the return value)
   my $line;      # current line from the file
   my @keyval;    # current key/value pair
   my $comments = "";
   my $currententry = 1;

   # make sure there are two arguments (sanity check on the calls)
   ( @_ == 2 ) || die "ReadINISection requires two parameters";

   # attempt to open the file
   open( INIFILE, $filename ) || return 0;

   # search for the section
   while ( $line = <INIFILE> )
      {
      if (( lc( $line ) =~ /\[$section\]/ ) || ( $section eq "" ))
         {
         # we want the first line if not doing a specific section
         $comments = $line if $section eq "";

         # Found the section we are looking for - now loop until end of section
         while ( $line = <INIFILE> )
            {
            if (( $line =~ /^\s*$/ ) || ( $line =~ /^\s*[;#]/ ))
               {
               # it is a comment character  (starts with # or ; after optional white space)
               $comments = $comments . $line;
               next;
               }

            # remove carriage return/line feed chars.  Chomp will not remove
            # the stupid DOS ^M.  This following substitution gets both.
            $line =~ s/[\015\012]+$//;

            if ( $line =~ /^\s*\[.*\]/ )  # note:  \s matches white space
               {
               # found a new section, bail out
               last;
               }

            @keyval = split( "=", $line, 2 );
            if ( @keyval == 2 )
               {
               # remove leading and trailing blank spaces
               $keyval[0] =~ s/^\s+//;
               $keyval[0] =~ s/\s+$//;
               $keyval[1] =~ s/^\s+//;
               $keyval[1] =~ s/\s+$//;

               # make the key lower case so we consistently read it
               $keyval[0] = lc( $keyval[0] );

               # store the key/value pair
               $pairs{ $keyval[0] } = $keyval[1] ;

               # store the key.comment/comment pair
               $pairs{ "$keyval[0].comment" } = $comments;

               # store the ordering info hash element
               $pairs{ "$currententry" } = $keyval[0];

               $comments = "";    # reset the comment collector variable

               # next entry
               $currententry++;

               }
            }  # while in the section
         }  # if in the section
      }  # while not eof



   close( INIFILE );


   # debug - print what we found
   #    my $sKey;
   #    foreach $sKey ( keys %pairs )
   #       {
   #       printf( "'%s'='%s'\n", $sKey, $pairs{ $sKey } );
   #       }
      #<STDIN>;


   # return the hash of keys and values
   return %pairs;

}  # ReadINISection


# filename is what the link will be pointing to. It can be another link instead
# of a file name.
# linkname is the new link.
# If bupdate is 0 it is removed if it exist and the new link created. If it is 1
# it is only updated if the filename is the same version or newer.
sub SetSpecificLink
{
   my ( $filename, $linkname, $bupdate ) = @_;
   my $oldverlinkname = "";


   if ( $bupdate == 0 )
      {
      # Create the version symbolic link. This link is always
      # created regardless if it is an older version being installed.
      unlink ( $linkname );
      symlink( $filename, $linkname ) ||
         die "Cannot create symbolic link to $filename";
      }
   else
      {
      if ( !( -f $linkname ))
         {
         # Link is not there so create one.
         symlink( $filename, $linkname ) ||
                        die "Cannot create symbolic link to $filename";
         }
      else
         {
         # Link exist so get the file name it is pointing to.
         $oldverlinkname = readlink $linkname;
         if ( !( "$oldverlinkname" eq "" ) )
            {
            # Got a file name. Since the version is in the file name, see
            # if the link needs updating. If the file names are the same
            # then leave the link alone since it is already correct. If
            # the file name is a newer version, leave it alone as well
            # since this link always points to the highest version of the
            # file.
            if ( "$oldverlinkname" lt $linkname )
               {
               # Update the link
               unlink( $linkname );
               symlink( $filename, $linkname ) ||
                        die "Cannot create symbolic link to $filename";
               }
            } # Got a file name that the link is pointing to
         } # File doesn't exists

      } # if $bupdate
} # SetSpecificLink

# SetLinks
# This needs to be called after the install is completed. This function
# updates/creates the major links like the "libace.so" link if the link
# doesn't exist or if the revision is the same or newer than the
# pre-existing file.
# The revision link, "for example libace.so.6.11", is always
# updated/created regardless pre-existing versions.
# Also, since this only runs if the install was successful, the
# files should exist but check to make sure.
#
sub SetLinks
{
   my $i;
   my $verlinkname;
   my $mainlinkname;
   my $oldverlinkname="";



   SetSpecificLink( "/usr/lib/$acefilename", "/usr/lib/$aceverlinkname", 0 );
   SetSpecificLink( "/usr/lib/$aceverlinkname", "/usr/lib/$acemainlinkname", 0 );


} # SetLinks


# This creates the index.htm file that has the links to the
# other help files. We can't simply copy a new file there in
# case another install (for example ARC) has updated it.
sub CreateMainHelp
{
   my ( $filename ) = @_;
   my $newindexfile = "";
   my $line = "";
   my $badsdone = 0;
   my $berrordone = 0;
   my $badvantagedone = 0;
   my $bfoundlinks = 0;


   $filename = "$filename/doc/index.html";

   if ( !( -e $filename ))
      {
      # File doesn't exist so just create one.
      $newindexfile = "<HTML>\n" .
                      "<BODY BGCOLOR=white>\n\n" .
                      "<CENTER>\n" .
                      "<H2>\n\n" .
                      "<P><A HREF=\"./Advantage/advantage.htm\">Advantage General Help</A>\n" .
                      "<P><A HREF=\"./ADSERROR/adserror.htm\">Advantage Error Codes</A>\n\n" .
                      "</CENTER>\n\n" .
                      "</BODY>\n" .
                      "</HTML>\n";

      if ( system( "touch $filename" ) )
         {
         die "Unable to create $filename:  $!";
         }

      WriteFile( $filename, $newindexfile );
      }
   else
      {
      # attempt to open the file
      open( INIFILE, $filename ) || return 0;

      # search for the section
      while ( $line = <INIFILE> )
         {
         # if there is a link find out if it links to one of the help files
         # we are installing.
         if ( $line =~ /href/i )
            {
            if ( $line =~ /advantage\/advantage.htm/i )
               {
               # The main advantage help file is in there
               # NOTE: We used to leave the entry alone if it already existed, but
               #       in 6.2 we accidentally shipped using lower-case directories for
               #       doc/ADSERROR and doc/Advantage, if we leave those links in here
               #       and the user installs 7.0 or newer over a 6.2 installation they
               #       won't see the links to the new help.
               # $badvantagedone = 1;
               $line = "";
               }

            if ( $line =~ /ads\/ads.htm/i )
               {
               # The ads help file is in there
               $line = "";
               }

            if ( $line =~ /adserror\/adserror.htm/i )
               {
               # The error help file is in there
               # NOTE: We used to leave the entry alone if it already existed, but
               #       in 6.2 we accidentally shipped using lower-case directories for
               #       doc/ADSERROR and doc/Advantage, if we leave those links in here
               #       and the user installs 7.0 or newer over a 6.2 installation they
               #       won't see the links to the new help.
               # $berrordone = 1;
               $line = "";
               }
            $bfoundlinks = 1;

            }
         else
            {
            if ( $bfoundlinks && $line ne "" )
               {
               # We are past the links and it isn't just a blank
               # line between the links. Now set the links that
               # weren't found in the file.
               if ( $badvantagedone == 0 )
                  {
                  $newindexfile = "$newindexfile<P><A HREF=\"" .
                     "./Advantage/advantage.htm\">Advantage General Help</A>\n";
                  }

               if ( $berrordone == 0 )
                  {
                  $newindexfile = "$newindexfile<P><A HREF=\"" .
                     "./ADSERROR/adserror.htm\">Advantage Error Help</A>\n";
                  }


               # We are done adding the links
               $bfoundlinks = 0;


               } # Past the link section
            } # if link section

         $newindexfile = "$newindexfile$line";
         } # # Read all the lines in the file

      WriteFile( $filename, $newindexfile );
      } # index file doesn't exist

}# CreateMainHelp


# write out the given string to a file
sub WriteFile
{
   my ( $filename, $newconf ) = @_;

   # try to open the file for output.  Not sure if this should be a fatal
   # error.  If we got this far (we were able to copy files into the directory
   # where we are trying to write to), then I'm not sure what would cause
   # the failure, but it seems unlikely that anything good is happening, so
   # just die for now.
   open( CONFFILE, "> $filename" ) || die "Unable to open $filename:  $!";

   printf( CONFFILE "%s", $newconf );

   close( CONFFILE );

}  # WriteFile

# Re-writes the adsscript to point to the installed location of the daemon
# Arguments:  1. string to search for 2. string to replace '1' with (if found)
sub ConfigureStartupFile
{
   my ($search, $replace) = @_;

   system( "sed -e 's|$search|$replace|g' $targetdir/script/ads > $targetdir/script/newadsscript");
   system( "mv $targetdir/script/newadsscript $targetdir/script/ads");
} #ConfigureStartupFile

# Configures the ADS Service.
sub ConfigureForStartup
{
   my $count = 0;

   if ($autostartup eq 'y')
      {
      if (system("cp $targetdir/script/ads /etc/init.d/ads")) { $count++; }
      if (system("chmod 755 /etc/init.d/ads")) { $count++; }
      if (system("/sbin/chkconfig --add ads")) { $count++; }

      if ($count)
         {
         print "\n There was an error when configuring Advantage to run as a system service \n";
         }
      }
} #ConfigureForStartup