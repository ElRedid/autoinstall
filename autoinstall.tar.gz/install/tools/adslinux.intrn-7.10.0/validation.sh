#!/bin/bash
# Este scrips ejecuta la primera fase de la isntalacion del ads, para generar el archivo con la webkey
SERIAL_NUMBER=$(cat /opt/install/tools/adslinux.intrn-7.10.0/setup.ini | grep "SERIAL_NUMBER=" | awk -F'=' '{print $2}')
VAL_CODE=$(cat /opt/install/tools/adslinux.intrn-7.10.0/setup.ini | grep "VAL_CODE=" | awk -F'=' '{print $2}')
echo "3" | /opt/install/tools/adslinux.intrn-7.10.0/adsstamp /usr/local/advantage/libadsd.so -prompt -serial $SERIAL_NUMBER -valcode $VAL_CODE -owner redid > /opt/install/tools/adslinux.intrn-7.10.0/webserial.txt
WEBSERIAL=$(cat /opt/install/tools/adslinux.intrn-7.10.0/webserial.txt | grep "Site Code:" | awk -F': ' '{print $2}')
echo "2 $SERIAL_NUMBER $WEBSERIAL" | /opt/install/tools/keygen-ads7 > /opt/install/tools/adslinux.intrn-7.10.0/keygencode.txt
cat /opt/install/tools/adslinux.intrn-7.10.0/keygencode.txt | awk -F'Key - ' '{print $2}' | awk 'NF'