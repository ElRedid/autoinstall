#!/bin/bash
# Este scrips ejecuta la primera fase de la isntalacion del 
# ads, para generar el archivo con la webkey

SERIAL_NUMBER=$(cat setup.ini | grep "SERIAL_NUMBER=" | awk -F'=' '{print $2}')
VAL_CODE=$(cat setup.ini | grep "VAL_CODE=" | awk -F'=' '{print $2}')

#echo $SERIAL_NUMBER
#echo $VAL_CODE
echo "3" | ./adsstamp /usr/local/advantage/libadsd.so -prompt -serial $SERIAL_NUMBER -valcode $VAL_CODE -owner redid > webserial.txt
WEBSERIAL=$(cat webserial.txt | grep "Site Code:" | awk -F': ' '{print $2}')
cd ..
echo "2 $SERIAL_NUMBER $WEBSERIAL" | ./keygen-ads7 > ./adslinux.intrn-7.10.0/keygencode.txt
cd ./adslinux.intrn-7.10.0
cat keygencode.txt | awk -F'Key - ' '{print $2}' | awk 'NF'