#!/bin/bash
# Script de interfaz para gestion de impresoras
# Julio Colmán <julio_colmant@hotmail.com>

export LANG=C

COMMANDENABLE=/usr/sbin/cupsenable
CONTROLER="sudo /bin/systemctl"

status_printers() {
    clear
    echo -e "[\033[1;33mPARA SALIR PRESIONE LA TECLA Q (quit=salir)\033[0m]"
    echo -e "\033[1;33mPuede desplazarse hacia arriba o hacia abajo con las flechitas\033[0m"
    

    lpstat -p > /dev/null 2>&1

    if [ $? -eq 0 ]; then

        printer_Stopped=$(lpstat -p | grep disabled | awk '{print $2}')
        printer_Disconected=$(lpstat -p | grep "now printing" | awk '{print $2}')
        printer_Idle=$(lpstat -p | grep "is idle" | awk '{print $2}')

        if [ -n "$printer_Stopped" ]; then 

            echo
            echo -e "\e[36mImpresora atascada - Requiere Liberacion\e[0m"


            for printer_name in $printer_Stopped; do

                echo -e "   [\033[0;31mSTOP\033[0m] $printer_name"
           
            done

        fi

        if [ -n "$printer_Disconected" ]; then

            echo
            echo -e "\e[36mImpresora ocupada o no responde\e[0m"

            for printer_name in $printer_Disconected; do

                echo -e "   [\e[35munavailable\e[0m] $printer_name" 

            done

        fi

        if [ -n "$printer_Idle" ]; then  

            echo
            echo -e "\e[36mImpresora disponible, esperando trabajo\e[0m"

            
            for printer_name in $printer_Idle; do

                echo -e "   [\033[0;32mOK\033[0m] $printer_name" 

            done

        fi

        echo

    elif [ $? -eq 1 ]; then
        echo "No hay impresoras instalas en el servidor"
    else
        echo "ERROR: Servicio CUPS no disponible"
    fi

    echo -e "\033[1;33mPuede desplazarse hacia arriba o hacia abajo con las flechitas\033[0m"
    echo -e "[\033[1;33mPARA SALIR PRESIONE LA TECLA Q (quit=salir)\033[0m]"

}

llama_status () {

    status_printers | less -R
    mostrar_menu

}



RstCups () {

    printer_Stopped=$(lpstat -p | grep disabled | awk '{print $2}')

    if [ -n "$printer_Stopped" ]; then

        $COMMANDENABLE $printer_Stopped

        $CONTROLER restart cups
    fi

}

liberando_impresora (){
    clear
    echo "Liberando Impresoras..."
    sleep 3
    RstCups
    echo "Listo!. Volviendo al menu principal"
    sleep 5
    mostrar_menu
}

limpiar_cola_impresion(){

    clear
    echo "Borrando la cola de impresion..."
    sleep 3
    cancel -a
    sudo /usr/bin/rm /var/spool/cups/* -Rf
   
    RstCups
    
    $CONTROLER restart cups
    clear
    echo "Listo!. Volviendo al menu principal"
    sleep 5

}

preguntar_limpiar_cola() {

    dialog --clear --title "CUIDADO!!!" --yesno "Limpiar la cola de Impresion ELIMINARA todas las impresiones pendientes, tendra que REENVIAR cada impresion de nuevo!!!\n¿Desea continuar?" 8 50

    respuesta=$?

    case $respuesta in
    0)
        limpiar_cola_impresion
        mostrar_menu
        ;;
    1)
        mostrar_menu
        ;;
    255)
        mostrar_menu
        ;;
    esac
    
}

mostrar_menu() {

    local opciones=(

        1 "Liberar Impresoras."
        2 "Status impresoras."
        3 "Borrar cola de Impresion"
        4 "Salir."
        
    )

    seleccion=$(dialog --clear \
                    --title "Control de Impresoras en Servidor" \
                    --menu "Seleccione una de las siguientes opciones:" 15 50 4 \
                    "${opciones[@]}" \
                    2>&1 >/dev/tty)
 case $seleccion in
        1) 
            liberando_impresora 
            ;;
        2) 
            llama_status
            ;;
        3) 
            preguntar_limpiar_cola 
            ;;
        4) 
            clear ;;
        *) 
            clear ;;
    esac
}

mostrar_menu
