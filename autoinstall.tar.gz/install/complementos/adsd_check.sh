#!/bin/bash
# Script que comprueba que el proceso ads este en ejecucion
# de no ser asi lo reinicia
# Dev: Julio Colman
# data: 02/11/2024

COMMAND="/bin/pgrep -x adsd"
RESTART="/bin/systemctl restart ads"

$COMMAND > /dev/null 2>&1 

if [ $? -ne 0 ]; then

    $RESTART > /dev/null 2>&1

fi

