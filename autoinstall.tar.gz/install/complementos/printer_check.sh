
#!/bin/bash
# Script encargado de detectar impresoras con el estado STOPPED en CUPS
# Por: Julio Colman
#  V-Estable 08/05/2024
#  Ajuste Rocky 24/10/2024

export LANG=C

COMMANDENABLE=/usr/sbin/cupsenable
CONTROLER=/bin/systemctl

RstCups () {

    printer_Stopped=$(lpstat -p | grep disabled | awk '{print $2}')

    if [ -n "$printer_Stopped" ]; then

        $COMMANDENABLE $printer_Stopped

        $CONTROLER restart cups
    fi
}

RstCups
