#!/bin/bash
# Herramienta para visualizar el estado de las impresoras instaladas en el sistema
# Por: Julio Colman 22/04/2024

export LANG=C
lpstat -p > /dev/null 2>&1

if [ $? -eq 0 ]; then
  printer_Stopped=$(lpstat -p | grep disabled | awk '{print $2}')
  printer_Disconected=$(lpstat -p | grep "now printing" | awk '{print $2}')
  printer_Idle=$(lpstat -p | grep "is idle" | awk '{print $2}')
  echo
  echo "State Idle:"
  for printer_name in $printer_Idle; do
    echo "- $printer_name"
  done

  echo
  echo "State Stopped"
  for printer_name in $printer_Stopped; do
    echo "- $printer_name"
  done

  echo
  echo "Disconected"
  for printer_name in $printer_Disconected; do
    echo "- $printer_name"
  done

  echo

elif [ $? -eq 1 ]; then

  echo "printstat Alert: No printers installed"

else

  echo "printstat ERROR: Unknown error"

fi


