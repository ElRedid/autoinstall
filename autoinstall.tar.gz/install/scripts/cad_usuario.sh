#!/bin/bash

for i in `cat users2.txt`; do

        adduser -g apache $i 
        echo "@$i!" | passwd --stdin $i

done

