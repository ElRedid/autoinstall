#!/bin/bash
# Validacion de password de usuario
# Criterios  --> Passwd no puede ser igual a User

checkpass(){
    cpass=$1
    echo "Changing password for user $cpass."
    read -p "New password: " -s pass
    echo
    if [ "$(echo "$cpass" | tr '[:upper:]' '[:lower:]')" = "$(echo "$pass" | tr '[:upper:]' '[:lower:]')" ]; then
        echo "BAD PASSWORD: The password is invalid."
        checkpass $cpass
    else
        read -p "Retype new password: " -s pass2
        echo
        if [ $pass2 == $pass ]; then
            echo $pass | passwd --stdin $cpass > /dev/null 2>&1
            echo "passwd: all authentication tokens updated successfully."
        else   
            echo "Sorry, passwords do not match."
            checkpass $cpass
        fi
    fi
}

if [ $# -eq 0 ]; then
    checkpass "root"
else
    usuario=$1
    ls /home/$usuario > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        checkpass $usuario
    else
        echo "passwd: Unknown user name '$usuario'."
    fi
fi

#passwd: all authentication tokens updated successfully.
#Sorry, passwords do not match.